####################################################

#              DEBUG CONFIG

aioff=0                          #ovo iskljucuje ai ako je 1

manualenemyplace=1               #ovo ti daje da placujes enemy kada pritisnes taster "e"

enemytype=1                      #ovo menja index kojeg enemia kada pritisnes dugme i ako je "manualenemyplace" ukljucen
                                 #tojest ako napises 1 onda ce enemy 1 biti postavljen i tako dalje

showstats=0                     #ako je ovo 1 onda u igri iznad lika vidis njegov movement speed,damage i hp

showanimstats=0                 #prikazivanje framea i animation statea

#             INFORMACIJE ZA DEBUGERA/BALANCERA

#SVI STATOVI KRECU OD LINIJE 318 (otprilike)

#TI STATOVI OVO ZNACE:

#charcd je lista svih cooldownova za dobre
#charcost je lista svih cena za dobre
#evilcost je lista svih cena za zlikovce (Ai trosi pare)
#goodstat je lista svih statova za dobre (pise koji su  statovi dole)
#evilstat je lista svih statova za lose

#evilcd (tojest) cooldowni za zlikovce NE POSTOJE
#charlist je lista unlockovanih charactera (i kasnije levela) TO NE DIRAJ!!! (osim ako ne dodajes nove charactere)
 

###########################################################

import pygame as pg
import random
import os
import json

pg.init()
pg.font.init()

width, height = 1500, 800
window = pg.display.set_mode((width, height))
game = 0

difficulty=0

endless=0
campaign=0

level=0

version = 2.0

clock = pg.time.Clock()
timer=0
autosave=0

sprites=[]

evilarmy=[]

charactercount=15

SAVE_FILE = "save.json"

def save_game():
    data = {
        "box": box,
        "charlist": charlist,
        "level": level,
        "version": version
    }
    with open(SAVE_FILE, "w") as f:
        json.dump(data, f)
    print("Game saved!")

def load_game():
    global box, charlist,level
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)

        save_version = data.get("version", 1)

        if save_version > version:
            # Save is from the future → reset
            print("Save file is from a newer version, wiping...")
            wipe_save()
            return

        box = data.get("box", 0)
        charlist = data.get("charlist", [])
        level = data.get("level", 0)

        if save_version < version:
            print("Old save detected, updating charlist...")
            while len(charlist) < charactercount:
                charlist.append(0)

        # Make sure it doesn’t go past current count
        charlist = charlist[:charactercount]


        print("Game loaded!")
    else:
        # no save file → reset progress
        box = 0
        charlist = [1]
        for i in range(charactercount-1):
            charlist.append(0)
        level=0
        print("No save file, starting fresh.")

def wipe_save():
    global box, charlist,level
    box = 0
    level=0
    charlist = [1]
    for i in range(charactercount-1):
            charlist.append(0)
    if os.path.exists(SAVE_FILE):
        os.remove(SAVE_FILE)
    print("Save data wiped!")

load_game()
save_game()

def createsprite(number, index):
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    assets_folder = os.path.join(script_dir, "ASSETS")
    prefix = f"{number}-"
    while len(sprites) <= index:
        sprites.append([])
    for filename in sorted(os.listdir(assets_folder)):
        if filename.startswith(prefix) and filename.endswith(".png"):
            img_path = os.path.join(assets_folder, filename)
            sprites[index].append(pg.image.load(img_path))

createsprite(1,0)
createsprite(2,1)
createsprite(3,2)
createsprite(4,3)
createsprite(5,4)
createsprite(6,5)
createsprite(7,6)
createsprite(8,7)
createsprite(9,8)
createsprite(0,9)
createsprite(12,10)
createsprite(13,11)
createsprite(14,12)
createsprite(15,13)
createsprite(16,14)



roll=0

menufont = pg.font.SysFont("Arial", 150)
menufont2 = pg.font.SysFont("Arial", 100)
valuefont = pg.font.SysFont("Arial", 50)

titlerect = pg.Rect(width / 2 - 600, 0, 1, 1)
titlerect2 = pg.Rect(width / 2 - 600, 120, 1, 1)

backtomenurect=pg.Rect(450,400,600,200)

b1 = pg.Rect(width / 2 - 500, 200, 1000, 150)
b2 = pg.Rect(width / 2 - 500, 400, 1000, 150)
b3 = pg.Rect(width / 2 - 500, 600, 1000, 150)
b4 = pg.Rect(25, 300, 450, 150)
b5 = pg.Rect(525, 300, 450, 150)
b6 = pg.Rect(1025, 300, 450, 150)

startbutton=pg.Rect(0,0,150,150)
backbutton=pg.Rect(1350,0,150,150)

charindex = 0

charb1 = pg.Rect(50, 200, 200, 200)
charb2 = pg.Rect(350, 200, 200, 200)
charb3 = pg.Rect(650, 200, 200, 200)
charb4 = pg.Rect(950, 200, 200, 200)
charb5 = pg.Rect(1250, 200, 200, 200)

char1 = -1
char2 = -1
char3 = -1
char4 = -1
char5 = -1

char1cd = 0
char2cd = 0
char3cd = 0
char4cd = 0
char5cd = 0

aidesiredunit = -1

gb1 = pg.Rect(325, 625, 150, 150)
gb2 = pg.Rect(500, 625, 150, 150)
gb3 = pg.Rect(675, 625, 150, 150)
gb4 = pg.Rect(850, 625, 150, 150)
gb5 = pg.Rect(1025, 625, 150, 150)

t1 = pg.Rect(1250, 200, 200, 400)
t2 = pg.Rect(50, 200, 200, 400)

blue = (0, 150, 250)
red = (255, 0, 0)
green = (0, 255, 0)
white = (255, 255, 255)
black = (0, 0, 0)
gray = (100, 100, 100)
yellow = (255, 255, 0)
cyan = (0, 255, 255)
Magenta = (255, 0, 255)



mon = 0
aimon1 = 0
aimon2 = 0
eff = 1
aieff1 = 1
aieff2 = 0.5
hp1 = 100
hp2 = 100

def click(button=pg.Rect(0,0,0,0),key=0,room=-100,special=0):
    if showstats:
        pg.draw.rect(window,red,button,10)
    global mousex,mousey,game,leftclick
    global charindex
    global enter
    global difficulty,endless,campaign
    if (leftclick and button.collidepoint(mousex,mousey)) or key:
        if room!=-100:
            game=room
            if game==-4:
                charindex=0
        leftclick=0
        if key==enter:
            enter=0
        if special==1:
            difficulty=1
        if special==2:
            difficulty=2
        if special==3:
            difficulty=3
        if special==4:
            endless=1
        else:
            endless=0
        if special==5:
            campaign=1
        else:
            campaign=0

goods = []
evils = []

def drawback(char, charcooldown, button):
    if char != -1:
        if charcd[char] == charcooldown and mon >= charcost[char]:
            pg.draw.rect(window, white, button)
        else:
            pg.draw.rect(window, gray, button)
    else:
        pg.draw.rect(window, gray, button)

class good:
    def __init__(self,
                 sprite,
                 mspeed,
                 range,
                 aspeed,
                 dmg,
                 hp,
                 chargeindex,
                 attackindex,
                 atype=0,
                 special=0,
                 Rect=None,
                 atick=0,
                 state=0,
                 aframe=0,
                 frametick=0,
                 animstate=0,
                 id=None):

        if Rect is None:
            self.Rect = pg.Rect(1300, 500, 100, 100)
        else:
            self.Rect = Rect
        self.mspeed = mspeed
        self.sprite = sprite
        self.range = range
        self.state = state
        self.aspeed = aspeed
        self.atick = atick
        self.dmg = dmg
        self.hp = hp
        self.id = id
        self.x = float(self.Rect.x)
        self.atype = atype
        self.chargeindex=chargeindex
        self.attackindex=attackindex
        self.aframe=aframe
        self.frametick=frametick
        self.animstate=animstate
        self.special=special

    def attack(self):
        global evils
        temprect = pg.Rect(self.Rect.x - self.range,
                           self.Rect.y,
                           self.range,
                           20)
        if not evils:
            self.state = 0
        if self.atype == 0:
            for o in evils:
                if temprect.colliderect(o.Rect):
                    self.state = 2
                    if self.animstate!=2:
                        self.animstate=1
                        
                    if self.atick != self.aspeed:
                        self.atick += 1
                    else:
                        self.atick = 0
                        o.hp -= self.dmg
                        if self.special==1:
                            o.Rect.x-=50
                            o.x-=50
                            o.atick=0
                            
                        self.animstate=2
                        self.aframe=self.attackindex
                    break
                else:
                    self.state = 0
        elif self.atype == 1:
            hit = False
            for u in evils:
                if u.Rect.colliderect(temprect):
                    if self.animstate!=2:
                        self.animstate=1
                        
                    hit = True
                    if self.atick != self.aspeed:
                        self.atick += 1
                        break
                    else:
                        self.atick = 0
                        for e in evils:
                            if e.Rect.colliderect(temprect):
                                e.hp -= self.dmg
                                if self.special==1:
                                    e.Rect.x-=50
                                    e.x-=50
                                    e.atick=0
                        self.animstate=2
                        self.aframe=self.attackindex
            self.state = 2 if hit else 0

    def towerattack(self):
        global hp2
        temprect = pg.Rect(self.Rect.x - self.range,
                           self.Rect.y,
                           self.range,
                           20)
        if temprect.colliderect(t2):
            self.state = 1
            if self.animstate!=2:
                self.animstate=1
                
            if self.atick != self.aspeed:
                self.atick += 1
            else:
                self.atick = 0
                hp2 -= self.dmg
                self.animstate=2
                self.aframe=self.attackindex
        if showstats:
            pg.draw.rect(window,"white",temprect)

    def draw(self):
        if self.chargeindex!=-1:
            if self.frametick!=10:
                self.frametick+=1
            else:
                self.frametick=0
                if self.animstate==0:
                    if self.aframe == self.chargeindex-1:
                        self.aframe=-1
                    self.aframe+=1
                if self.animstate==1:
                    if self.aframe == self.attackindex-1:
                        
                        self.aframe=self.chargeindex-1
                    self.aframe+=1
                if self.animstate==2:
                    self.aframe+=1
                    if self.aframe==len(sprites[self.sprite]):
                        self.animstate=1
                        self.aframe=len(sprites[self.sprite])-1

                if self.aframe>len(sprites[self.sprite])-1:
                    self.aframe=0

            if self.animstate==1 and self.aframe<=self.chargeindex:
                self.aframe=self.chargeindex
        else:
            if self.frametick!=10:
                self.frametick+=1
            else:
                self.frametick=0
                if self.aframe!=len(sprites[self.sprite])-1:
                    self.aframe+=1
                else:
                    self.aframe=0


        if showstats:
            txt=valuefont.render(f"hp:{self.hp}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-100))
            txt=valuefont.render(f"dmg:{self.dmg}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-50))
            txt=valuefont.render(f"speed:{self.mspeed}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-150))
            txt=valuefont.render(f"special:{self.special}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-200))
        
        if showanimstats:
            txt=valuefont.render(f"state:{self.animstate}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-100))
            txt=valuefont.render(f"frame:{self.aframe}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-50))
            txt=valuefont.render(f"tick:{self.frametick}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-150))
            
            

        window.blit(sprites[self.sprite][self.aframe],self.Rect)

            

    def tempmove(self):
        if self.state == 0:
            self.x -= self.mspeed
            self.Rect.x = int(self.x)
            self.animstate=0
            self.atick=0

    def ded(self):
        if self.hp <= 0:
            goods.remove(self)

class evil:
    def __init__(self,
                 sprite,
                 mspeed,
                 range,
                 aspeed,
                 dmg,
                 hp,
                 chargeindex,
                 attackindex,
                 atype=0,
                 Rect=None,
                 atick=0,
                 state=0,
                 aframe=0,
                 frametick=0,
                 animstate=0,
                 id=None):

        if Rect is None:
            self.Rect = pg.Rect(100, 500, 100, 100)
        else:
            self.Rect = Rect
        self.mspeed = mspeed
        self.sprite = sprite
        self.range = range
        self.state = state
        self.aspeed = aspeed
        self.atick = atick
        self.dmg = dmg
        self.hp = hp
        self.id = id
        self.x = float(self.Rect.x)
        self.atype = atype
        self.chargeindex = chargeindex
        self.attackindex = attackindex
        self.aframe = aframe
        self.frametick = frametick
        self.animstate = animstate

    def attack(self):
        global goods
        temprect = pg.Rect(self.Rect.x + self.Rect.width,
                           self.Rect.y,
                           self.range,
                           20)
        if not goods:
            self.state = 0
        if self.atype == 0:
            for o in goods:
                if temprect.colliderect(o.Rect):
                    self.state = 2
                    if self.animstate != 2:
                        self.animstate = 1
                        
                    if self.atick != self.aspeed:
                        self.atick += 1
                        break
                    else:
                        self.atick = 0
                        for e in goods:
                            if e.Rect.colliderect(temprect):
                                if e.special!=2:
                                    e.hp -= self.dmg
                                else:
                                    e.hp-=1
                                
                        
                        self.animstate = 2
                        self.aframe = self.attackindex
                    break
                else:
                    self.state = 0
        elif self.atype == 1:
            hit = False
            for u in goods:
                if u.Rect.colliderect(temprect):
                    if self.animstate != 2:
                        self.animstate = 1
                        
                    hit = True
                    if self.atick != self.aspeed:
                        self.atick += 1
                    else:
                        self.atick = 0
                        if u.special!=2:
                            u.hp -= self.dmg
                        else:
                            u.hp-=1
                        self.animstate = 2
                        self.aframe = self.attackindex
            self.state = 2 if hit else 0

    def towerattack(self):
        global hp1
        temprect = pg.Rect(self.Rect.x + self.Rect.width,
                           self.Rect.y,
                           self.range,
                           20)
        if temprect.colliderect(t1):
            self.state = 1
            if self.animstate != 2:
                self.animstate = 1
                self.aframe = self.chargeindex
            if self.atick != self.aspeed:
                self.atick += 1
            else:
                self.atick = 0
                hp1 -= self.dmg
                self.animstate = 2
                self.aframe = self.attackindex
        if showstats:
            pg.draw.rect(window, "white", temprect)

    def draw(self):
        if self.chargeindex!=-1:
            if self.frametick != 10:
                self.frametick += 1
            else:
                self.frametick = 0
                if self.animstate == 0:
                    if self.aframe>=self.chargeindex:
                        self.aframe=0

                    if self.aframe == self.chargeindex - 1:
                        self.aframe = -1
                    self.aframe += 1
                if self.animstate == 1:
                    if self.aframe>=self.attackindex:
                        self.aframe=0
                    if self.aframe == self.attackindex - 1:
                        self.aframe = self.chargeindex - 1
                    self.aframe += 1
                if self.animstate == 2:
                    self.aframe += 1
                    if self.aframe == len(sprites[self.sprite]):
                        self.animstate = 0
                        self.aframe = len(sprites[self.sprite]) - 1

                if self.aframe>len(sprites[self.sprite])-1:
                    self.aframe=0

            if self.animstate==1 and self.aframe<=self.chargeindex:
                self.aframe=self.chargeindex
        
        else:
            if self.frametick!=10:
                self.frametick+=1
            else:
                self.frametick=0
                if self.aframe!=len(sprites[self.sprite])-1:
                    self.aframe+=1
                else:
                    self.aframe=0


        if showstats:
            txt = valuefont.render(f"hp:{self.hp}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 100))
            txt = valuefont.render(f"dmg:{self.dmg}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 50))
            txt = valuefont.render(f"speed:{self.mspeed}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 150))

        if showanimstats:
            txt = valuefont.render(f"state:{self.animstate}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 100))
            txt = valuefont.render(f"frame:{self.aframe}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 50))
            txt = valuefont.render(f"tick:{self.frametick}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 150))

        # Blit the horizontally mirrored sprite
        img = sprites[self.sprite][self.aframe]
        flipped_img = pg.transform.flip(img, True, False)
        window.blit(flipped_img, self.Rect)

    def tempmove(self):
        if self.state == 0:
            self.x += self.mspeed
            self.Rect.x = int(self.x)
            self.animstate = 0
            self.atick=0

    def ded(self):
        if self.hp <= 0:
            evils.remove(self)
#OVDE KRECU STATOVI

boxrolls=[10,11,12,13,14]            #indexi svih mogucih rollova iz boxa

charcd = [60, 120, 240, 330, 380, 600, 300, 450, 1800, 3000,6000,240,1000,6000,400,0,0,0,0,0,0,0,0,0,0,0,0,0]
#charlist je sad na liniji otprilike 79 zbog save fileova
charcost = [75, 150, 200, 290, 340, 300, 540, 600, 790, 1000,600,300,500,400,500,0,0,0,0]
evilcost = [100, 150, 300, 600, 360, 340, 600, 820, 1350,2000]


goodstat = [                              
    (0, 1, 1, 60, 2, 5, 0,0,3,4), 
    (1, 0.8, 1, 100, 1, 30, 1,0,3,4),
    (2, 1, 20, 30, 5, 7, 0,0,3,4),
    (3, 1, 100, 80, 4, 12, 0,0, 3, 4),
    (4, 3, 1, 20, 1, 5, 0,0, 3, 4),
    (5, 1.5, 40, 70, 4, 4, 1,0, 3, 4),
    (6, 0.6, 1, 150, 30, 45, 0,0, 3, 4),
    (7, 0.6, 150, 120, 25, 5, 0,0, 3, 4),
    (8, 0.5, 1, 240, 30, 100, 1,0, 3, 4),
    (9, 0.2, 400, 600, 130, 2, 1,0, 3, 6),
    (10, 2, 1, 4, 1, 2, 0,2, -1, 0),
    (11, 1, 1, 80, 3, 15, 0,0, 3, 4),
    (12,0.8,300,300,10,20,0,1,3,6),
    (13,0.1,600,400,1,1,0,1,4,8),
    (14,0.8,1,120,1,30,1,2,3,4)
    

]
    #sprite,movement speed,range,attack speed,damage,hp,targets(samo za zlikovce optional),special(z nemaju),frame do kog se lik krece,frame do kog se lik charguje

evilstat = [
    (0, 1, 1, 60, 2, 5, 3, 4),
    (1, 0.9, 1, 90, 1, 35, 3, 4),
    (2, 1, 15, 30, 7, 7, 3, 4),
    (3, 1, 90, 70, 3.5, 15, 3, 4),
    (4, 4, 1 , 15, 0.5, 3, 3, 4),
    (5, 1.7, 45, 75, 4.5, 3,  3, 4, 1),
    (6, 0.6, 1, 160, 35, 45, 3, 4),
    (7, 0.4, 190, 240, 10, 5, 3, 4),
    (8, 0.5, 1, 300, 25, 160, 3, 4, 1),
    (9, 0.1, 450, 800, 180, 1 , 3, 6, 1)



]

#OVDE SE ZAVRSAVAJU STATOVI

def create(char, button, key, charcooldown):
    global mon
    global char1cd, char2cd, char3cd, char4cd, char5cd
    if char != -1 and charcooldown >= charcd[char]:
        if mon >= charcost[char] and ((button.collidepoint(mousex, mousey) and leftclick) or key):
            sprite, mspeed, range_, aspeed, dmg, hp, atype, special, chargeindex, attackindex = goodstat[char]
            goods.append(good(
                sprite,
                mspeed,
                range_,
                aspeed,
                dmg,
                hp,
                chargeindex,
                attackindex,
                atype,
                special,
                pg.Rect(1300, 500, 100, 100)
            ))
            mon -= charcost[char]
            if button == gb1:
                char1cd = 0
            if button == gb2:
                char2cd = 0
            if button == gb3:
                char3cd = 0
            if button == gb4:
                char4cd = 0
            if button == gb5:
                char5cd = 0

#############################################################################################################################################

while True:
    mousex, mousey = pg.mouse.get_pos()
    leftclick = 0
    enter = 0
    left = 0
    right = 0
    shift = 0
    space = 0
    e=0
    back=0

    k1 = 0
    k2 = 0
    k3 = 0
    k4 = 0
    k5 = 0
    for event in pg.event.get():
        if event.type == pg.QUIT:
            quit()
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1:
                leftclick = 1
        if event.type == pg.KEYDOWN:

            if event.key == pg.K_KP_ENTER or event.key==pg.K_RETURN:
                enter = 1
            if event.key == pg.K_LEFT:
                left = 1
            if event.key == pg.K_RIGHT:
                right = 1
            if event.key == pg.K_1 or event.key== pg.K_KP1:
                k1 = 1
            if event.key == pg.K_2 or event.key== pg.K_KP2:
                k2 = 1
            if event.key == pg.K_3 or event.key== pg.K_KP3:
                k3 = 1
            if event.key == pg.K_4 or event.key== pg.K_KP4:
                k4 = 1
            if event.key == pg.K_5 or event.key== pg.K_KP5:
                k5 = 1
            if event.key == pg.K_SPACE:
                space = 1
            if event.key == pg.K_e:
                e = 1
            if event.key == pg.K_BACKSPACE:
                back = 1

            if event.key == pg.K_ESCAPE:
                game = 0
                endless=0

    keys = pg.key.get_pressed()
    if keys[pg.K_LSHIFT] or keys[pg.K_RSHIFT]:
        shift = 1

    if game == 0 or game == -1 or game == -2 or game == -3 or game==-7 or game==-8 or game==-9 or game==-10:
        window.fill(blue)
        txt = menufont.render("BATTLE STICKS 2", True, "white")
        window.blit(txt, titlerect)
        

    if game == 0:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        pg.draw.rect(window, "white", b3)
        txt = menufont.render("        PLAY", True, "black")
        window.blit(txt, b1)
        txt = menufont.render("     SETTINGS", True, "black")
        window.blit(txt, b2)
        txt = menufont.render("       EXTRAS", True, "black")
        window.blit(txt, b3)
        click(b1, enter, -1)
        txt = valuefont.render(f"version {version}", True, "black")
        window.blit(txt, (0,725))
        click(b3, 0, -7)
        click(b2, 0, -10)

    if game == -1:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        txt = menufont.render("    singleplayer", True, "black")
        window.blit(txt, b1)
        txt = menufont.render("[COMING SOON]", True, "black")
        window.blit(txt, b2)
        
        click(b1, enter, -2)
        

    if game == -2:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        pg.draw.rect(window, "white", b3)
        txt = menufont.render("       classic", True, "black")
        window.blit(txt, b1)
        if level!=8:
            txt = menufont.render("      campaign", True, "black")
        else:
            if charlist[9]==0:
                txt = menufont.render("   BOSS FIGHT", True, red)
            else:
                txt = menufont.render("campaign complete", True, green)
        window.blit(txt, b2)
        txt = menufont.render("         more", True, "black")
        window.blit(txt, b3)
        click(b1, enter, -3)
        click(b3, 0, -9)
        click(b2, 0, -4,5)

    if game == -3:
        txt = menufont.render("    select difficulty", True, "white")
        window.blit(txt, titlerect2)
        pg.draw.rect(window, "white", b4)
        txt = menufont.render(" easy", True, "black")
        window.blit(txt, b4)
        pg.draw.rect(window, "white", b5)
        txt = menufont.render(" normal", True, "black")
        window.blit(txt, b5)
        pg.draw.rect(window, "white", b6)
        txt = menufont.render(" hard", True, "black")
        window.blit(txt, b6)
        
        click(b4, 0, -4,1)
        click(b5, enter, -4,2)
        click(b6, 0, -4,3)

    if game==-7:
        pg.draw.rect(window,white,b4)
        txt=menufont2.render('BOX',True,black)
        window.blit(txt,b4)
        txt=menufont2.render(str(box),True,black)
        window.blit(txt,(b4.right-100,b4.bottom-100))
        if leftclick and b4.collidepoint(mousex,mousey) and box>0:
            roll=random.choice(boxrolls)
            charlist[roll]=1
            leftclick=0
            box-=1
            game=-8
        pg.draw.rect(window,white,backbutton)
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0

    if game==-8:
        txt=menufont.render('      YOU GOT',True,white)
        window.blit(txt,titlerect2)
        scaled_image = pg.transform.scale(sprites[roll][0], (400, 400))
        window.blit(scaled_image, (550,400))
        if leftclick:
            leftclick=0
            game=-7

    if game == -9:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        pg.draw.rect(window, "white", b3)
        txt = menufont.render("       endless", True, "black")
        window.blit(txt, b1)
        txt = menufont.render("[COMING SOON]", True, "black")
        window.blit(txt, b2)
        txt = menufont.render("[COMING SOON]", True, "black")
        window.blit(txt, b3)
        click(b1, enter, -4,4)

    if game==-10:
        pg.draw.rect(window,white,b4)
        txt=menufont2.render('Save',True,black)
        window.blit(txt,b4)
        pg.draw.rect(window,white,b5)
        txt=menufont2.render('WIPE DATA',True,red)
        window.blit(txt,b5)
        if leftclick and b4.collidepoint(mousex,mousey):
            save_game()
        if leftclick and b5.collidepoint(mousex,mousey):
            wipe_save()

        pg.draw.rect(window,white,backbutton)
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0
        

    if game == -4:
        window.fill("tan")
        txt = menufont2.render("     SELECT CHARACTERS", True, "white")
        window.blit(txt, titlerect)

        pg.draw.rect(window, "white", charb1)
        pg.draw.rect(window, "white", charb2)
        pg.draw.rect(window, "white", charb3)
        pg.draw.rect(window, "white", charb4)
        pg.draw.rect(window, "white", charb5)

        if char1 != -1:
            scaled_image = pg.transform.scale(sprites[char1][0], (200, 200))
            window.blit(scaled_image, charb1)

        if char2 != -1:
            scaled_image = pg.transform.scale(sprites[char2][0], (200, 200))
            window.blit(scaled_image, charb2)

        if char3 != -1:
            scaled_image = pg.transform.scale(sprites[char3][0], (200, 200))
            window.blit(scaled_image, charb3)

        if char4 != -1:
            scaled_image = pg.transform.scale(sprites[char4][0], (200, 200))
            window.blit(scaled_image, charb4)

        if char5 != -1:
            scaled_image = pg.transform.scale(sprites[char5][0], (200, 200))
            window.blit(scaled_image, charb5)

        br = 675 - (charindex * 200)
        pg.draw.rect(window, "black", (650, 575, 200, 200))
        for i in range(len(charlist)):
            object = charlist[i]
            if char1!=i and char2!=i and char3!=i and char4!=i and char5!=i:
                pg.draw.rect(window, "white", (br, 600, 150, 150))
            else:
                pg.draw.rect(window, gray, (br, 600, 150, 150))
            if object == 1:
                scaled_image = pg.transform.scale(sprites[i][0], (150, 150))
                window.blit(scaled_image, (br, 600, 100, 100))
            else:
                txt = menufont.render("?", True, "black")
                window.blit(txt, (br, 600, 100, 100))
            br += 200

        if charb1.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            char1=-1
        if charb2.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            char2=-1
        if charb3.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            char3=-1
        if charb4.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            char4=-1
        if charb5.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            char5=-1
        

        if (left or (pg.Rect(0,400,150,400).collidepoint(mousex,mousey) and leftclick)) and charindex != 0:
            charindex -= 1
        if (right or (pg.Rect(1350,400,150,400).collidepoint(mousex,mousey) and leftclick)) and charindex != len(charlist) - 1:
            charindex += 1
        if (enter or (leftclick and pg.Rect(675,600,150,150).collidepoint(mousex,mousey))) and charlist[charindex] != 0:
            if charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5:
                enter = 0
                if char1 == -1:
                    char1 = charindex
                elif char2 == -1:
                    char2 = charindex
                elif char3 == -1:
                    char3 = charindex
                elif char4 == -1:
                    char4 = charindex
                elif char5 == -1:
                    char5 = charindex

        if k1:
            if not shift and charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5 and charlist[charindex]!=0:
                char1 = charindex
            elif shift:
                char1 = -1
        if k2:
            if not shift and charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5 and charlist[charindex]!=0:
                char2 = charindex
            elif shift:
                char2 = -1
        if k3:
            if not shift and charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5 and charlist[charindex]!=0:
                char3 = charindex
            elif shift:
                char3 = -1
        if k4:
            if not shift and charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5 and charlist[charindex]!=0:
                char4 = charindex
            elif shift:
                char4 = -1
        if k5:
            if not shift and charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5 and charlist[charindex]!=0:
                char5 = charindex
            elif shift:
                char5 = -1

        if back==1:
            char1=-1
            char2=-1
            char3=-1
            char4=-1
            char5=-1

        if (char1 != -1 or char2 != -1 or char3 != -1 or char4 != -1 or char5 != -1):
            pg.draw.rect(window,white,startbutton)
            txt=valuefont.render("START!",True,black)
            window.blit(txt,startbutton)

        pg.draw.rect(window,white,backbutton)
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0

        if (space or (startbutton.collidepoint(mousex,mousey) and leftclick)) and (char1 != -1 or char2 != -1 or char3 != -1 or char4 != -1 or char5 != -1):
            mon = 0
            aimon1 = 0
            aimon2 = 0
            game = 1
            eff = 1

            
            evilarmy.clear()
            for i in range(len(evilcost)):
                evilarmy.append(i)
            hp1 = 100
            hp2 = 100
            goods.clear()
            evils.clear()
            char1cd = charcd[char1]
            char2cd = charcd[char2]
            char3cd = charcd[char3]
            char4cd = charcd[char4]
            char5cd = charcd[char5]
            leftclick=0
            if difficulty==1:
                aieff1 = 0.6
                aieff2 = 0.3
            if difficulty==2:
                aieff1 = 1
                aieff2 = 0.6
            if difficulty==3:
                aieff1 = 1.5
                aieff2 = 1
            if endless:
                aieff1=1
                aieff2=0.6
                hp2=9999999999999999999
            timer=0
            if campaign:
                if level==0:
                    evilarmy=[0]
                    aieff1=0.3
                    aieff2=0
                    hp2=10
                if level==1:
                    evilarmy=[0,1]
                    aieff1=0.3
                    aieff2=0.1
                    hp2=20
                if level==2:
                    evilarmy=[0,1]
                    aieff1=0.5
                    aieff2=0.15
                    hp2=40
                if level==3:
                    evilarmy=[0,1,2]
                    aieff1=0.5
                    aieff2=0.3
                    hp2=80
                if level==4:
                    evilarmy=[0,1,2,3]
                    aieff1=0.6
                    aieff2=0.35
                    hp2=100
                if level==5:
                    evilarmy=[0,1,2,3,4,5]
                    aieff1=0.7
                    aieff2=0.4
                    hp2=100
                if level==6:
                    evilarmy=[0,1,2,3,4,5,6,7]
                    aieff1=0.8
                    aieff2=0.45
                    hp2=100
                if level==7:
                    evilarmy=[0,1,2,3,4,5,6,7,8,9]
                    aieff1=1
                    aieff2=0.5
                    hp2=100
                if level==8:
                    evilarmy=[0,1,2,3,4,5,6,7,8,9]
                    aieff1=0.5
                    aieff2=0.25
                    hp2=300

    if game == 1:
        window.fill(blue)

        if char1 != -1 and char1cd < charcd[char1]:
            char1cd += 1
        if char2 != -1 and char2cd < charcd[char2]:
            char2cd += 1
        if char3 != -1 and char3cd < charcd[char3]:
            char3cd += 1
        if char4 != -1 and char4cd < charcd[char4]:
            char4cd += 1
        if char5 != -1 and char5cd < charcd[char5]:
            char5cd += 1

        mon += eff
        aimon1 += aieff1
        aimon2 += aieff2
        if not aioff:
            if random.randint(0, 100) == 10:
                char = evilcost.index(evilcost[random.choice(evilarmy)])
                if aimon1 >= evilcost[char]:
                    try:
                        sprite, mspeed, range_, aspeed, dmg, hp, chargeindex, attackindex, atype = evilstat[enemytype-1]
                    except ValueError:
                        sprite, mspeed, range_, aspeed, dmg, hp, chargeindex, attackindex = evilstat[enemytype-1]
                        
                        atype = 0
                    evils.append(evil(
                        sprite,
                        mspeed,
                        range_,
                        aspeed,
                        dmg,
                        hp,
                        chargeindex,
                        attackindex,
                        atype,
                        pg.Rect(100, 500, 100, 100)
                    ))
                    aimon1 -= evilcost[char]

            if aidesiredunit == -1:
                aidesiredunit = evilcost.index(evilcost[random.choice(evilarmy)])
            elif aimon2 >= evilcost[aidesiredunit] and random.randint(0,2)==2:
                try:
                    sprite, mspeed, range_, aspeed, dmg, hp, chargeindex, attackindex, atype = evilstat[aidesiredunit]
                except ValueError:
                    sprite, mspeed, range_, aspeed, dmg, hp, chargeindex, attackindex = evilstat[aidesiredunit]
                    atype = 0
                evils.append(evil(
                    sprite,
                    mspeed,
                    range_,
                    aspeed,
                    dmg,
                    hp,
                    chargeindex,
                    attackindex,
                    atype,
                    pg.Rect(100, 500, 100, 100)
                ))
                aimon2 -= evilcost[aidesiredunit]
                aidesiredunit=-1

        if e and manualenemyplace:
            try:
                sprite, mspeed, range_, aspeed, dmg, hp, chargeindex, attackindex, atype = evilstat[enemytype-1]
            except ValueError:
                sprite, mspeed, range_, aspeed, dmg, hp, chargeindex, attackindex = evilstat[enemytype-1]
                atype = 0
            evils.append(evil(sprite, mspeed, range_, aspeed, dmg, hp, chargeindex, attackindex, atype, pg.Rect(100, 500, 100, 100)))

        pg.draw.rect(window, "green", (0, 600, 1500, 200))
        pg.draw.rect(window, "gray", t1)
        pg.draw.rect(window, "gray", t2)

        txt = valuefont.render(str(hp1), True, "black")
        window.blit(txt, t1)
        if hp2>1000:
            txt = valuefont.render('Infinite', True, "black")
        else:
            txt = valuefont.render(str(hp2), True, "black")
        window.blit(txt, t2)

        txt = valuefont.render(f"{round(mon)}$", True, "black")
        window.blit(txt, (1350, 0, 1, 1))

        drawback(char1, char1cd, gb1)
        drawback(char2, char2cd, gb2)
        drawback(char3, char3cd, gb3)
        drawback(char4, char4cd, gb4)
        drawback(char5, char5cd, gb5)

        if char1 != -1:
            scaled_image = pg.transform.scale(sprites[char1][0], (150, 150))
            window.blit(scaled_image, gb1)
            txt = valuefont.render(f"{charcost[char1]}$", True, "black")
            window.blit(txt, (gb1.x, gb1.y + 100, 1, 1))
        if char2 != -1:
            scaled_image = pg.transform.scale(sprites[char2][0], (150, 150))
            window.blit(scaled_image, gb2)
            txt = valuefont.render(f"{charcost[char2]}$", True, "black")
            window.blit(txt, (gb2.x, gb2.y + 100, 1, 1))
        if char3 != -1:
            scaled_image = pg.transform.scale(sprites[char3][0], (150, 150))
            window.blit(scaled_image, gb3)
            txt = valuefont.render(f"{charcost[char3]}$", True, "black")
            window.blit(txt, (gb3.x, gb3.y + 100, 1, 1))
        if char4 != -1:
            scaled_image = pg.transform.scale(sprites[char4][0], (150, 150))
            window.blit(scaled_image, gb4)
            txt = valuefont.render(f"{charcost[char4]}$", True, "black")
            window.blit(txt, (gb4.x, gb4.y + 100, 1, 1))
        if char5 != -1:
            scaled_image = pg.transform.scale(sprites[char5][0], (150, 150))
            window.blit(scaled_image, gb5)
            txt = valuefont.render(f"{charcost[char5]}$", True, "black")
            window.blit(txt, (gb5.x, gb5.y + 100, 1, 1))

        create(char1, gb1, k1, char1cd)
        create(char2, gb2, k2, char2cd)
        create(char3, gb3, k3, char3cd)
        create(char4, gb4, k4, char4cd)
        create(char5, gb5, k5, char5cd)

        for i in goods:
            i.attack()
            i.towerattack()
            i.tempmove()
            i.draw()
            i.ded()

        for i in evils:
            i.attack()
            i.towerattack()
            i.tempmove()
            i.draw()
            i.ded()

        timer+=16
        
        if endless:
            
            if timer%(16*60*20)==0:
                aieff1+=0.2
                aieff2+=0.1
            txt=valuefont.render(str(round((timer/1000),2)),True,black)
            window.blit(txt,(0,0))

        if campaign:
            txt=valuefont.render(f"Level {level+1}",True,black)
            window.blit(txt,(0,0))
            if level==8:
                if timer==(16*60*5):
                    evils.append(evil(9,0.2,600,1000,200,100,3,6,1))
                

        if hp1<=0 or hp2<=0:
            
            mon = 0
            aimon1 = 0
            aimon2 = 0
            goods.clear()
            evils.clear()
            char1cd = 0
            char2cd = 0
            char3cd = 0
            char4cd = 0
            char5cd = 0
            if campaign:
                if level<=7:
                    level+=1
                    charlist[level]=1
                if level==8:
                    charlist[level+1]=1
                
            save_game()
            
            
            random.seed()

        if hp1<=0:
            game=-6
        if hp2<=0:
            game=-5
            if not campaign:
                box+=1

    if game==-5 or game==-6:
        window.fill(white)
        if game==-5:
            txt=menufont.render('YOU WIN!',True,black)
            
            
        if game==-6:
            txt=menufont.render('YOU LOSE!',True,black)
            if endless:
                txt=menufont.render(f"Time:{round(((timer/1000),2))}")
                window.blit(txt,(300,600))
        
        
        window.blit(txt,titlerect)
        pg.draw.rect(window,gray,backtomenurect)
        txt=menufont2.render("back to menu",True,black)
        window.blit(txt,backtomenurect)
        click(backtomenurect,enter,0)


    pg.display.update()
    clock.tick(60)
    autosave+=1
    if autosave==(60*45):
        autosave=0
        save_game()