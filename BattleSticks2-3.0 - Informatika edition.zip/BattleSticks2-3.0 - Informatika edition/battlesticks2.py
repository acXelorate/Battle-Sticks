####################################################

#              DEBUG CONFIG

aioff=0                          #ovo iskljucuje ai ako je 1

manualenemyplace=1               #ovo ti daje da placujes enemy kada pritisnes taster "e"

enemytype=12                      #ovo menja index kojeg enemia kada pritisnes dugme i ako je "manualenemyplace" ukljucen
                                 #tojest ako napises 1 onda ce enemy 1 biti postavljen i tako dalje

showstats=0                     #ako je ovo 1 onda u igri iznad lika vidis njegov movement speed,damage i hp

showanimstats=0                 #prikazivanje framea i animation statea

showfps=0                       #prikazivanje fps

performancemode=0               #ne renderuje pozadinu i to

#             INFORMACIJE ZA DEBUGERA/BALANCERA

#SVI STATOVI KRECU OD LINIJE 318 (otprilike)

#TI STATOVI OVO ZNACE:

#charcd je lista svih cooldownova za dobre
#charcost je lista svih cena za dobre
#evilcost je lista svih cena za zlikovce (Ai trosi pare)
#goodstat je lista svih statova za dobre (pise koji su  statovi dole)
#evilstat je lista svih statova za lose

#evilcd (tojest) cooldowni za zlikovce NE POSTOJE
#charlist je lista unlockovanih charactera (i kasnije levela) TO NE DIRAJ!!! (osim ako ne dodajes nove charactere)
 
#           GUIDE ZA SONGOVE

#song 1 -> main menu , song 2 -> choose characters , song 3 -> basic fight (3,4)easy (5,6)hard  11->prima o fortuna
#song 12-> alien
#

###########################################################

import pygame as pg
import random
import os
import json
import datetime

today=datetime.date.today()
day_number=today.weekday()
#day_number=6



pg.init()
pg.font.init()
try:
    pg.mixer.init()
    print("Welcome back!")
    MIXER_WORKING = True
except Exception as e:
    MIXER_WORKING = False
    class DummySound:
        def play(self, *a, **k): pass
        def stop(self): pass
        def set_volume(self, *a, **k): pass

    class DummyMusic:
        def load(self, *a, **k): pass
        def play(self, *a, **k): pass
        def stop(self): pass
        def pause(self): pass
        def unpause(self): pass
        def rewind(self): pass
        def set_volume(self, *a, **k): pass
        def get_busy(self): return False

    class DummyMixer:
        Sound = lambda *a, **k: DummySound()
        music = DummyMusic()

    pg.mixer = DummyMixer()

megafont=pg.font.SysFont('Arial',200)

width, height = 1500, 800
window = pg.display.set_mode((width, height))
game = 0

frame=0
frametick=0

song=0

difficulty=0

endless=0
campaign=0
multiplayer=0

player=0

level=0

version = 3.0

clock = pg.time.Clock()
timer=0
autosave=0

pg.mixer.music.set_volume(0.1)

background=0
ground=0

slider_x, slider_y = 50, 600
slider_w, slider_h = 300, 10

sprites=[]

evilarmy=[]

charactercount=20

SAVE_FILE = "save.json"

def save_game():
    data = {
        "box": box,
        "charlist": charlist,
        "level": level,
        "version": version
    }
    with open(SAVE_FILE, "w") as f:
        json.dump(data, f)

def load_game():
    global box, charlist,level
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)

        save_version = data.get("version", 1)

        if save_version > version:
            # Save is from the future → reset
            print("Save file is from a newer version, wiping...")
            wipe_save()
            return

        box = data.get("box", 0)
        charlist = data.get("charlist", [])
        level = data.get("level", 0)

        if save_version < version:
            
            while len(charlist) < charactercount:
                charlist.append(0)

        # Make sure it doesn’t go past current count
        charlist = charlist[:charactercount]



    else:
        # no save file → reset progress
        box = 0
        charlist = [1]
        for i in range(charactercount-1):
            charlist.append(0)
        level=0
        print("No save file, starting fresh.")

def wipe_save():
    global box, charlist,level
    box = 0
    level=0
    charlist = [1]
    for i in range(charactercount-1):
            charlist.append(0)
    if os.path.exists(SAVE_FILE):
        os.remove(SAVE_FILE)
    

load_game()
save_game()

def createsprite(number, index):
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    assets_folder = os.path.join(script_dir, "ASSETS")
    prefix = f"{number}-"
    while len(sprites) <= index:
        sprites.append([])
    for filename in sorted(os.listdir(assets_folder)):
        if filename.startswith(prefix) and filename.endswith(".png"):
            img_path = os.path.join(assets_folder, filename)
            sprites[index].append(pg.image.load(img_path).convert_alpha())

script_dir = os.path.dirname(__file__)
sound_path = os.path.join(script_dir, "ASSETS", "sfx-1.ogg")
clicksfx = pg.mixer.Sound(sound_path)
clicksfx.set_volume(0.05)



def load_music(filename: str):
    global song
    if filename!=song:
        music_path = os.path.join(script_dir, "ASSETS", filename)
        pg.mixer.music.load(music_path)
        pg.mixer.music.play(-1)
        song=filename

def choosesong(songs:tuple):
    choice=random.choice(songs)
    load_music(choice)
    

load_music("song-1.mp3")


createsprite(1,0)
createsprite(2,1)
createsprite(3,2)
createsprite(4,3)
createsprite(5,4)
createsprite(6,5)
createsprite(7,6)
createsprite(8,7)
createsprite(9,8)
createsprite(0,9)
createsprite(12,10)
createsprite(13,11)
createsprite(14,12)
createsprite(15,13)
createsprite(16,14)
createsprite(17,15)
createsprite(18,16)
createsprite(19,17)
createsprite(20,18)
createsprite(21,19)
createsprite(22,20)
createsprite(23,21)
createsprite(24,22)


createsprite(-1,100)
createsprite(-2,101)
createsprite(-3,102)
createsprite(-4,103)
createsprite(-5,104)
createsprite(-6,105)



roll=0

menufont = pg.font.SysFont("Arial", 150)
menufont2 = pg.font.SysFont("Arial", 100)
valuefont = pg.font.SysFont("Arial", 50)
valuefont2 = pg.font.SysFont("Arial", 40)

titlerect = pg.Rect(width / 2 - 600, 0, 450, 100)
titlerect2 = pg.Rect(width / 2 - 600, 120, 1, 1)

backtomenurect=pg.Rect(450,400,600,200)

b1 = pg.Rect(width / 2 - 500, 200, 1000, 150)
b2 = pg.Rect(width / 2 - 500, 400, 1000, 150)
b3 = pg.Rect(width / 2 - 500, 600, 1000, 150)
b4 = pg.Rect(25, 300, 450, 150)
b5 = pg.Rect(525, 300, 450, 150)
b6 = pg.Rect(1025, 300, 450, 150)

exitb=pg.Rect(width/2+550,600,150,150)

startbutton=pg.Rect(0,0,150,150)
backbutton=pg.Rect(1350,0,150,150)
infobutton=pg.Rect(1150,0,150,150)

charindex = 0

charb1 = pg.Rect(50, 200, 200, 200)
charb2 = pg.Rect(350, 200, 200, 200)
charb3 = pg.Rect(650, 200, 200, 200)
charb4 = pg.Rect(950, 200, 200, 200)
charb5 = pg.Rect(1250, 200, 200, 200)

char1 = -1
char2 = -1
char3 = -1
char4 = -1
char5 = -1

char6 = -1
char7 = -1
char8 = -1
char9 = -1
char10 = -1

char1cd = 0
char2cd = 0
char3cd = 0
char4cd = 0
char5cd = 0

char6cd = 0
char7cd = 0
char8cd = 0
char9cd = 0
char10cd = 0

aidesiredunit = -1

gb1 = pg.Rect(325, 625, 150, 150)
gb2 = pg.Rect(500, 625, 150, 150)
gb3 = pg.Rect(675, 625, 150, 150)
gb4 = pg.Rect(850, 625, 150, 150)
gb5 = pg.Rect(1025, 625, 150, 150)
gb6 = pg.Rect(1325,625,150,150)
gb7 = pg.Rect(25,625,150,150)

multibutton=[]
tempx=7
for i in range(14):
    multibutton.append(pg.Rect(tempx,625,100,100))
    tempx+=107
    

cannoncd=0
upmon=0
cannontype=0
fire=0

cannoncd2=0
fire2=0
upmon2=0

t1 = pg.Rect(1250, 200, 200, 400)
t2 = pg.Rect(50, 200, 200, 400)

blue = (0, 150, 250)
red = (255, 0, 0)
green = (0, 255, 0)
white = (255, 255, 255)
black = (0, 0, 0)
gray = (100, 100, 100)
yellow = (255, 255, 0)
cyan = (0, 255, 255)
Magenta = (255, 0, 255)



mon = 0
aimon1 = 0
aimon2 = 0
eff = 1
aieff1 = 1
aieff2 = 0.5
hp1 = 100
hp2 = 100

def click(button=pg.Rect(0,0,0,0),key=0,room=-100,special=0):
    if showstats:
        pg.draw.rect(window,red,button,10)
    global mousex,mousey,game,leftclick
    global charindex,frame,frametick
    global enter
    global difficulty,endless,campaign,multiplayer
    global player
    if (leftclick and button.collidepoint(mousex,mousey)) or key:
        clicksfx.play()
        if room!=-100:
            game=room
            if game==-4:
                charindex=0
        leftclick=0
        if key is enter:
            enter=0
        if special==1:
            difficulty=1
        if special==2:
            difficulty=2
        if special==3:
            difficulty=3
        if special==4:
            endless=1
        else:
            endless=0
        if special==5:
            campaign=1
        else:
            campaign=0
        if special==6:
            multiplayer=1
            player=0
        else:
            multiplayer=0
            player=1
        if special==7:
            difficulty=4
        if room==-4:
            load_music("song-2.mp3")
        if room==0:
            load_music("song-1.mp3")
        if 8<=special<=14:
            difficulty=special-3
        if special==15:
            charindex=0
            frame=0
            
            

days=["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]

def stage():
    
    txt = menufont.render(f"{days[day_number]} stage", True, "black")
    window.blit(txt, b3)
    click(b3,0,-4,day_number+8)


goods = []
evils = []

def drawback(char, charcooldown, button):
    if char != -1:
        if charcd[char] == charcooldown and mon >= charcost[char]:
            pg.draw.rect(window, white, button)
        else:
            pg.draw.rect(window, gray, button)
    else:
        pg.draw.rect(window, gray, button)

def drawback2(char, charcooldown, button):
    if char != -1:
        if charcd[char] == charcooldown and aimon1 >= charcost[char]:
            pg.draw.rect(window, white, button)
        else:
            pg.draw.rect(window, gray, button)
    else:
        pg.draw.rect(window, gray, button)

class good:
    def __init__(self,
                 sprite,
                 mspeed,
                 range,
                 aspeed,
                 dmg,
                 hp,
                 atype=0,
                 special=0,
                 chargeindex=-1,
                 attackindex=-1,
                 Rect=None,
                 atick=0,
                 state=0,
                 aframe=0,
                 frametick=0,
                 animstate=0,
                 id=None):

        if Rect is None:
            self.Rect = pg.Rect(1300, 500, 100, 100)
        else:
            self.Rect = Rect
        self.mspeed = mspeed
        self.sprite = sprite
        self.range = range
        self.state = state
        self.aspeed = aspeed
        self.atick = atick
        self.dmg = dmg
        self.hp = hp
        self.id = id
        self.x = float(self.Rect.x)
        self.atype = atype
        self.chargeindex=chargeindex
        self.attackindex=attackindex
        self.aframe=aframe
        self.frametick=frametick
        self.animstate=animstate
        self.special=special

    def attack(self):
        global evils
        temprect = pg.Rect(self.Rect.x - self.range,
                           self.Rect.y,
                           self.range,
                           20)
        if not evils:
            self.state = 0
        if self.atype == 0:
            for o in evils:
                if temprect.colliderect(o.Rect):
                    self.state = 2
                    if self.animstate!=2:
                        self.animstate=1
                        
                    if self.atick != self.aspeed:
                        self.atick += 1
                    else:
                        target=None
                        for g in evils:
                            if g.Rect.colliderect(temprect):
                                if  target is None or evils[target].x>g.x:
                                    target=evils.index(g)
                        self.atick = 0
                        
                        if evils[target].special==2:
                            evils[target].hp -= 1
                        else:
                            if self.special==3 and evils[target].trait==1:
                                evils[target].hp -= self.dmg*2
                            else:
                                evils[target].hp -= self.dmg
                        if self.special==1:
                            evils[target].Rect.x-=50
                            evils[target].x-=50
                            evils[target].atick=0
                            
                        self.animstate=2
                        self.aframe=self.attackindex
                    break
                else:
                    self.state = 0
        elif self.atype == 1:
            hit = False
            for u in evils:
                if u.Rect.colliderect(temprect):
                    if self.animstate!=2:
                        self.animstate=1
                        
                    hit = True
                    if self.atick != self.aspeed:
                        self.atick += 1
                        break
                    else:
                        self.atick = 0
                        for e in evils:
                            if e.Rect.colliderect(temprect):
                                if e.special==2:
                                    e.hp-=1
                                else:
                                    e.hp -= self.dmg
                                if self.special==1:
                                    e.Rect.x-=50
                                    e.x-=50
                                    e.atick=0
                        self.animstate=2
                        self.aframe=self.attackindex
            self.state = 2 if hit else 0

    def towerattack(self):
        global hp2
        temprect = pg.Rect(self.Rect.x - self.range,
                           self.Rect.y,
                           self.range,
                           20)
        if temprect.colliderect(t2):
            self.state = 1
            if self.animstate!=2:
                self.animstate=1
                
            if self.atick != self.aspeed:
                self.atick += 1
            else:
                self.atick = 0
                hp2 -= self.dmg
                self.animstate=2
                self.aframe=self.attackindex
        if showstats:
            pg.draw.rect(window,"white",temprect)

    def draw(self):
        if self.chargeindex!=-1:
            if self.frametick!=10:
                self.frametick+=1
            else:
                
                self.frametick=0
                if self.animstate==0:
                    if self.aframe == self.chargeindex-1:
                        self.aframe=-1
                    self.aframe+=1
                if self.animstate==1:
                    if self.aframe == self.attackindex-1:
                        
                        self.aframe=self.chargeindex-1
                    self.aframe+=1
                if self.animstate==2:
                    self.aframe+=1
                    if self.aframe==len(sprites[self.sprite]):
                        self.animstate=1
                        self.aframe=len(sprites[self.sprite])-1

                if self.aframe>len(sprites[self.sprite])-1:
                    self.aframe=0

            if self.animstate==1 and self.aframe<=self.chargeindex:
                self.aframe=self.chargeindex
        else:
            if self.frametick!=10:
                self.frametick+=1
            else:
                self.frametick=0
                if self.aframe!=len(sprites[self.sprite])-1:
                    self.aframe+=1
                else:
                    self.aframe=0


        if showstats:
            txt=valuefont.render(f"hp:{self.hp}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-100))
            txt=valuefont.render(f"dmg:{self.dmg}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-50))
            txt=valuefont.render(f"speed:{self.mspeed}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-150))
            txt=valuefont.render(f"special:{self.special}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-200))
        
        if showanimstats:
            txt=valuefont.render(f"state:{self.animstate}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-100))
            txt=valuefont.render(f"frame:{self.aframe}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-50))
            txt=valuefont.render(f"tick:{self.frametick}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-150))
            
            

        window.blit(sprites[self.sprite][self.aframe],self.Rect)

            

    def tempmove(self):
        if self.state == 0:
            self.x -= self.mspeed
            self.Rect.x = int(self.x)
            self.animstate=0
            self.atick=0

    def ded(self):
        if self.hp <= 0:
            goods.remove(self)

class evil:
    def __init__(self,
                 sprite,
                 mspeed,
                 range,
                 aspeed,
                 dmg,
                 hp,
                 atype,
                 special,
                 chargeindex,
                 attackindex,
                 trait=0,
                 Rect=None,
                 atick=0,
                 state=0,
                 aframe=0,
                 frametick=0,
                 animstate=0,
                 id=None):

        if Rect is None:
            self.Rect = pg.Rect(100, 500, 100, 100)
        else:
            self.Rect = Rect
        self.mspeed = mspeed
        self.sprite = sprite
        self.range = range
        self.state = state
        self.aspeed = aspeed
        self.atick = atick
        self.dmg = dmg
        self.hp = hp
        self.id = id
        self.x = float(self.Rect.x)
        self.atype = atype
        self.chargeindex = chargeindex
        self.attackindex = attackindex
        self.aframe = aframe
        self.frametick = frametick
        self.animstate = animstate
        self.special=special
        self.trait=trait

    def attack(self):
        global goods
        temprect = pg.Rect(self.Rect.right,
                           self.Rect.y,
                           self.range,
                           20)
        if not goods:
            self.state = 0
        if self.atype == 0:
            for o in goods:
                if temprect.colliderect(o.Rect):
                    self.state = 2
                    if self.animstate!=2:
                        self.animstate=1
                        
                    if self.atick != self.aspeed:
                        self.atick += 1
                    else:
                        target=None
                        for g in goods:
                            if g.Rect.colliderect(temprect):
                                if target is None or goods[target].x<g.x:
                                    target=goods.index(g)
                        self.atick = 0
                        if goods[target].special==2:
                            goods[target].hp -= 1
                        else:
                            goods[target].hp -= self.dmg
                        if self.special==1:
                            goods[target].Rect.x+=50
                            goods[target].x+=50
                            goods[target].atick=0
                            
                        self.animstate=2
                        self.aframe=self.attackindex
                    break
                else:
                    self.state = 0
        elif self.atype == 1:
            hit = False
            for u in goods:
                if u.Rect.colliderect(temprect):
                    if self.animstate!=2:
                        self.animstate=1
                        
                    hit = True
                    if self.atick != self.aspeed:
                        self.atick += 1
                        break
                    else:
                        self.atick = 0
                        for e in goods:
                            if e.Rect.colliderect(temprect):
                                if e.special==2:
                                    e.hp-=1
                                else:
                                    e.hp -= self.dmg
                                if self.special==1:
                                    e.Rect.x+=50
                                    e.x+=50
                                    e.atick=0
                        self.animstate=2
                        self.aframe=self.attackindex
            self.state = 2 if hit else 0


    def towerattack(self):
        global hp1
        temprect = pg.Rect(self.Rect.x + self.Rect.width,
                           self.Rect.y,
                           self.range,
                           20)
        if temprect.colliderect(t1):
            self.state = 1
            if self.animstate != 2:
                self.animstate = 1
                self.aframe = self.chargeindex
            if self.atick != self.aspeed:
                self.atick += 1
            else:
                self.atick = 0
                hp1 -= self.dmg
                self.animstate = 2
                self.aframe = self.attackindex
        if showstats:
            pg.draw.rect(window, "white", temprect)

    def draw(self):
        if self.chargeindex!=-1:
            if self.frametick != 10:
                self.frametick += 1
            else:
                self.frametick = 0
                if self.animstate == 0:
                    if self.aframe>=self.chargeindex:
                        self.aframe=0

                    if self.aframe == self.chargeindex - 1:
                        self.aframe = -1
                    self.aframe += 1
                if self.animstate == 1:
                    if self.aframe>=self.attackindex:
                        self.aframe=0
                    if self.aframe == self.attackindex - 1:
                        self.aframe = self.chargeindex - 1
                    self.aframe += 1
                if self.animstate == 2:
                    self.aframe += 1
                    if self.aframe == len(sprites[self.sprite]):
                        self.animstate = 0
                        self.aframe = len(sprites[self.sprite]) - 1

                if self.aframe>len(sprites[self.sprite])-1:
                    self.aframe=0

            if self.animstate==1 and self.aframe<=self.chargeindex:
                self.aframe=self.chargeindex
        
        else:
            if self.frametick!=10:
                self.frametick+=1
            else:
                self.frametick=0
                if self.aframe!=len(sprites[self.sprite])-1:
                    self.aframe+=1
                else:
                    self.aframe=0


        if showstats:
            txt = valuefont.render(f"hp:{self.hp}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 100))
            txt = valuefont.render(f"dmg:{self.dmg}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 50))
            txt = valuefont.render(f"speed:{self.mspeed}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 150))
            txt=valuefont.render(f"special:{self.special}",True,black)
            window.blit(txt,(self.Rect.x,self.Rect.y-200))

        if showanimstats:
            txt = valuefont.render(f"state:{self.animstate}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 100))
            txt = valuefont.render(f"frame:{self.aframe}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 50))
            txt = valuefont.render(f"tick:{self.frametick}", True, black)
            window.blit(txt, (self.Rect.x, self.Rect.y - 150))

        # Blit the horizontally mirrored sprite
        img = sprites[self.sprite][self.aframe]
        flipped_img = pg.transform.flip(img, True, False)
        window.blit(flipped_img, self.Rect)

    def tempmove(self):
        if self.state == 0:
            self.x += self.mspeed
            self.Rect.x = int(self.x)
            self.animstate = 0
            self.atick=0

    def ded(self):
        if self.hp <= 0:
            evils.remove(self)
#OVDE KRECU STATOVI

boxrolls=[10,11,12,13,14,19]            #indexi svih mogucih rollova iz boxa

charcd = [60, 120, 240, 330, 380, 600, 300, 450, 1800, 3000,6000,240,1000,6000,400,400,400,180,240,600,0,0,0,0,0,0,0,0]
#charlist je sad na liniji otprilike 79 zbog save fileova
charcost = [75, 150, 200, 290, 340, 300, 540, 600, 790, 1000,600,300,500,400,500,500,400,300,400,450,0,0,0,0,0,0,0,0,0]
evilcost = [100, 150, 300, 600, 360, 340, 602, 820, 1350,2000,-1,601,800,1000]

goodnames=['Batter','Shielder','Fighter','Ranger','Rusher','Boomer','Crusher','Flame Mage','Titan','Doomer','Log','Boxer','Buccaneer','Sniper','Ultra Shield','The Horse','Mad Lad','Terminator','Explorer','Gardener']
evilnames=['Batter','Shielder','Fighter','Ranger','Rusher','Boomer','Crusher','Flame Mage','Titan','Doomer','Marko','Alien Batter','Alien Commander','Cyborg']



goodstat = [                              
    (0, 1, 1, 60, 2, 5, 0,0,3,4), 
    (1, 0.8, 1, 100, 1, 30, 1,0,3,4),
    (2, 1, 20, 50, 5, 7, 0,0,3,4),
    (3, 1, 100, 80, 4, 12, 0,0, 3, 4),
    (4, 3, 1, 20, 1, 20, 0,0, 3, 4),
    (5, 1.5, 40, 70, 4, 4, 1,0, 3, 4),
    (6, 0.6, 1, 150, 30, 45, 0,0, 3, 4),
    (7, 0.6, 150, 120, 25, 5, 0,0, 3, 4),
    (8, 0.5, 1, 240, 30, 100, 1,0, 3, 4),
    (9, 0.2, 400, 600, 130, 2, 1,0, 3, 6),
    (10, 2, 1, 4, 1, 2, 0,2, -1, 0),
    (11, 1, 20, 80, 3, 15, 0,1, 3, 4),
    (12,0.8,300,300,10,20,0,1,3,6),
    (13,0.1,600,400,1,1,0,1,4,8),
    (14,0.8,1,120,1,30,1,2,3,4),
    (15,2.5,1,30,5,5,0,0,3,4),
    (17,1,60,120,10,10,1,3,3,4),
    (19,1,20,60,7,10,0,3,3,4),
    (21,1,200,60,3,5,1,3,3,4),
    (22,0.5,1,2,0.1,15,0,0,3,4)

    

]
    #sprite,movement speed,range,attack speed,damage,hp,targets,special,frame do kog se lik krece,frame do kog se lik charguje

evilstat = [
    (0, 1, 1, 60, 2, 5,0,0 ,3, 4),
    (1, 0.9, 1, 90, 1, 35,0,0, 3, 4),
    (2, 1, 15, 30, 7, 7,0,0, 3,4),
    (3, 1, 90, 70, 3.5, 15,0,0, 3, 4),
    (4, 4, 1 , 15, 0.5, 3,0,0, 3, 4),
    (5, 1.7, 45, 75, 4.5, 3,1,0,  3, 4),
    (6, 0.6, 1, 160, 35, 45,0,0, 3, 4),
    (7, 0.4, 190, 240, 10, 5,0,0, 3, 4),
    (8, 0.5, 1, 300, 25, 160,1,0, 3, 4),
    (9, 0.1, 450, 800, 180, 1 ,1,0, 3, 6),
    (15, 2.5, 1, 15, 10, 3, 0, 2, 3, 4),
    (16,0.8,10,60,60,20,0,0,3,4,1),
    (18,0.6,100,60,10,6,1,0,3,4,1),
    (20,1.2,1,240,30,20,1,2,3,4,1)

    #sprite,movement speed,range,attack speed,damage,hp,targets,special,frame do kog se lik krece,frame do kog se lik charguje

]

#OVDE SE ZAVRSAVAJU STATOVI

def create(char, button, key, charcooldown):
    global mon
    global char1cd, char2cd, char3cd, char4cd, char5cd
    if char != -1 and charcooldown >= charcd[char]:
        if mon >= charcost[char] and ((button.collidepoint(mousex, mousey) and leftclick) or key):
            goods.append(good(*goodstat[char]))
            mon -= charcost[char]
            if not multiplayer:
                if button == gb1:
                    char1cd = 0
                if button == gb2:
                    char2cd = 0
                if button == gb3:
                    char3cd = 0
                if button == gb4:
                    char4cd = 0
                if button == gb5:
                    char5cd = 0
            else:
                if button == multibutton[7]:
                    char1cd = 0
                if button == multibutton[8]:
                    char2cd = 0
                if button == multibutton[9]:
                    char3cd = 0
                if button == multibutton[10]:
                    char4cd = 0
                if button == multibutton[11]:
                    char5cd = 0


def create2(char, button, key, charcooldown):
    global aimon1
    global char6cd, char7cd, char8cd, char9cd, char10cd
    if char != -1 and charcooldown >= charcd[char]:
        if aimon1 >= charcost[char] and ((button.collidepoint(mousex, mousey) and leftclick) or key):
            
            evils.append(evil(*goodstat[char]))
            aimon1 -= charcost[char]
            if button == multibutton[2]:
                char6cd = 0
            if button == multibutton[3]:
                char7cd = 0
            if button == multibutton[4]:
                char8cd = 0
            if button == multibutton[5]:
                char9cd = 0
            if button == multibutton[6]:
                char10cd = 0

#############################################################################################################################################

while True:
    mousex, mousey = pg.mouse.get_pos()
    leftclick = 0
    enter = 0
    left = 0
    right = 0
    shift = 0
    space = 0
    e=0
    back=0
    up=0
    down=0
    p=0
    o=0
    q=0
    w=0

    k1 = 0
    k2 = 0
    k3 = 0
    k4 = 0
    k5 = 0
    k6=0
    k7=0
    k8=0
    k9=0
    k0=0
    for event in pg.event.get():
        if event.type == pg.QUIT:
            quit()
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1:
                leftclick = 1
        if event.type == pg.KEYDOWN:

            if event.key == pg.K_KP_ENTER or event.key==pg.K_RETURN:
                enter = 1
            if event.key == pg.K_LEFT:
                left = 1
            if event.key == pg.K_RIGHT:
                right = 1
            if event.key == pg.K_UP:
                up = 1
            if event.key == pg.K_DOWN:
                down = 1
            if event.key == pg.K_1 or event.key== pg.K_KP1:
                k1 = 1
            if event.key == pg.K_2 or event.key== pg.K_KP2:
                k2 = 1
            if event.key == pg.K_3 or event.key== pg.K_KP3:
                k3 = 1
            if event.key == pg.K_4 or event.key== pg.K_KP4:
                k4 = 1
            if event.key == pg.K_5 or event.key== pg.K_KP5:
                k5 = 1
            if event.key == pg.K_6 or event.key== pg.K_KP6:
                k6 = 1
            if event.key == pg.K_7 or event.key== pg.K_KP7:
                k7 = 1
            if event.key == pg.K_8 or event.key== pg.K_KP8:
                k8 = 1
            if event.key == pg.K_9 or event.key== pg.K_KP9:
                k9 = 1
            if event.key == pg.K_0 or event.key== pg.K_KP0:
                k0 = 1
            if event.key == pg.K_SPACE:
                space = 1
            if event.key == pg.K_e:
                e = 1
            if event.key == pg.K_q:
                q = 1
            if event.key == pg.K_w:
                w = 1
            if event.key == pg.K_o:
                o = 1
            if event.key == pg.K_p:
                p = 1
            if event.key == pg.K_BACKSPACE:
                back = 1

            if event.key == pg.K_ESCAPE:
                game = 0
                load_music("song-1.mp3")
                endless=0
                clicksfx.play()

    keys = pg.key.get_pressed()
    if keys[pg.K_LSHIFT] or keys[pg.K_RSHIFT]:
        shift = 1

    if game == 0 or game == -1 or game == -2 or game == -3 or game==-7 or game==-8 or game==-9 or game==-10:
        window.fill(blue)
        txt = menufont.render("BATTLE STICKS 2", True, "white")
        window.blit(txt, titlerect)
        

    if game == 0:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        pg.draw.rect(window, "white", b3)
        pg.draw.rect(window,"white",exitb)
        window.blit(sprites[105][0],exitb)
        if leftclick and exitb.collidepoint(mousex,mousey):
            save_game()
            pg.quit()
            exit()
            break
        txt = menufont.render("        PLAY", True, "black")
        window.blit(txt, b1)
        txt = menufont.render("     SETTINGS", True, "black")
        window.blit(txt, b2)
        txt = menufont.render("       EXTRAS", True, "black")
        window.blit(txt, b3)
        click(b1, enter, -1)
        txt = valuefont.render(f"version {version}", True, "black")
        window.blit(txt, (0,725))
        click(b3, 0, -7)
        click(b2, 0, -10)

    if game == -1:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        txt = menufont.render("    singleplayer", True, "black")
        window.blit(txt, b1)
        txt = menufont.render("    multiplayer", True, "black")
        window.blit(txt, b2)
        
        click(b1, enter, -2)
        click(b2, 0, -4,6)
        

    if game == -2:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        pg.draw.rect(window, "white", b3)
        txt = menufont.render("       classic", True, "black")
        window.blit(txt, b1)
        if level<=8:
            txt = menufont.render("      campaign", True, "black")
        else:
            txt = menufont.render("      campaign", True, cyan)
        
        if level==8:
            txt = menufont.render("   BOSS FIGHT", True, red)
        if charlist[18]==1:
            txt = menufont.render("campaign complete", True, green)
        window.blit(txt, b2)
        txt = menufont.render("         more", True, "black")
        window.blit(txt, b3)
        click(b1, enter, -3)
        click(b3, 0, -9)
        click(b2, 0, -4,5)

    if game == -3:
        txt = menufont.render("    select difficulty", True, "white")
        window.blit(txt, titlerect2)
        pg.draw.rect(window, "white", b4)
        txt = menufont.render(" easy", True, "black")
        window.blit(txt, b4)
        pg.draw.rect(window, "white", b5)
        txt = menufont.render(" normal", True, "black")
        window.blit(txt, b5)
        pg.draw.rect(window, "white", b6)
        txt = menufont.render(" hard", True, "black")
        window.blit(txt, b6)
        
        click(b4, 0, -4,1)
        click(b5, enter, -4,2)
        click(b6, 0, -4,3)

    if game==-7:
        pg.draw.rect(window,white,b4)
        pg.draw.rect(window,white,b5)
        pg.draw.rect(window,white,b6)
        txt=menufont2.render('BOX',True,black)
        window.blit(txt,b4)
        txt=menufont2.render(str(box),True,black)
        window.blit(txt,(b4.right-100,b4.bottom-100))
        txt=menufont2.render('GOODS',True,black)
        window.blit(txt,b5)
        txt=menufont2.render('EVILS',True,black)
        window.blit(txt,b6)
        if leftclick and b4.collidepoint(mousex,mousey) and box>0:
            roll=random.choice(boxrolls)
            charlist[roll]=1
            leftclick=0
            box-=1
            game=-8
            save_game()
        pg.draw.rect(window,white,backbutton)
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0
            clicksfx.play()
            load_music("song-1.mp3")
        click(b5,0,-11,15)
        click(b6,0,-12,15)

    if game==-11:
        window.fill(blue)
        pg.draw.rect(window,green,(0,600,1500,200))
        pg.draw.rect(window,white,backbutton)
        
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0
            clicksfx.play()
            load_music("song-1.mp3")
        if charlist[charindex]==1:
            pg.draw.rect(window,white,infobutton)
            txt=menufont.render("i",True,black)
            window.blit(txt,infobutton)
            if infobutton.collidepoint(mousex,mousey) and leftclick:
                leftclick=0
                game=-13
                clicksfx.play()
            frametick+=1
            if frametick==20:
                frametick=0
                if frame!=len(sprites[goodstat[charindex][0]])-1:
                    frame+=1
                else:
                    frame=0
            pg.draw.rect(window,white,(0,200,230,120))
            
            if goodstat[charindex][6]==0:
                txt=menufont2.render("single",True,black)
            else:
                txt=menufont2.render("multi",True,black)
            window.blit(txt,(0,200))

            if goodstat[charindex][7]!=0:
                pg.draw.rect(window,white,(0,430,400,120))
                if goodstat[charindex][7]==1:
                    txt=menufont2.render("knockback",True,black)
                elif goodstat[charindex][7]==2:
                    txt=menufont2.render("metal",True,black)
                elif goodstat[charindex][7]==3:
                    txt=menufont2.render("anti-alien",True,black)
                window.blit(txt,(0,430))

            
            txt=menufont.render(str(goodnames[charindex]),True,white)
            window.blit(txt,(0,0))
            scaled_image = pg.transform.scale(sprites[goodstat[charindex][0]][frame], (400, 400))
            window.blit(scaled_image, (550,200))

        else:
            txt=valuefont.render('you have not discovered this character yet',True,white)
            window.blit(txt,(0,0))
            txt=megafont.render('?',True,white)
            window.blit(txt, (550,200))
        if left and charindex!=0:
            charindex-=1
            frame=0
            frameindex=0
            left=0
        if right and charindex!=len(charlist)-1:
            charindex+=1
            frame=0
            frameindex=0
            right=0
                                
    if game==-13:
        window.fill(blue)
        pg.draw.rect(window,white,backbutton)
        
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=-11
            clicksfx.play()
            load_music("song-1.mp3")
        txtlist=[menufont2.render(f'hp:{goodstat[charindex][5]}',True,white),
                 menufont2.render(f'damage:{goodstat[charindex][4]}',True,white),
                 menufont2.render(f'attack speed:{int(goodstat[charindex][3]/60) if (goodstat[charindex][3]/60).is_integer() else round(goodstat[charindex][3]/60,2)}',True,white),
                 menufont2.render(f'movement speed:{goodstat[charindex][1]}',True,white),
                 menufont2.render(f'range:{goodstat[charindex][2]}',True,white)]
        txt=menufont2.render(str(goodnames[charindex]),True,white)
        window.blit(txt,(0,0))
        tempy=100
        for i in range(len(txtlist)):
            window.blit(txtlist[i],(0,tempy))
            tempy+=100

    if game==-14:
        window.fill(blue)
        pg.draw.rect(window,white,backbutton)
        
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=-12
            clicksfx.play()
            load_music("song-1.mp3")
        txtlist=[menufont2.render(f'hp:{evilstat[charindex][5]}',True,white),
                 menufont2.render(f'damage:{evilstat[charindex][4]}',True,white),
                 menufont2.render(f'attack speed:{int(evilstat[charindex][3]/60) if (evilstat[charindex][3]/60).is_integer() else round(evilstat[charindex][3]/60,2)}',True,white),
                 menufont2.render(f'movement speed:{evilstat[charindex][1]}',True,white),
                 menufont2.render(f'range:{evilstat[charindex][2]}',True,white)]
        txt=menufont2.render(str(evilnames[charindex]),True,white)
        window.blit(txt,(0,0))
        tempy=100
        for i in range(len(txtlist)):
            window.blit(txtlist[i],(0,tempy))
            tempy+=100

    if game==-12:
        window.fill(blue)
        pg.draw.rect(window,green,(0,600,1500,200))
        pg.draw.rect(window,white,backbutton)
        pg.draw.rect(window,white,infobutton)
        txt=menufont.render("i",True,black)
        window.blit(txt,infobutton)
        if infobutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=-14
            clicksfx.play()
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0
            clicksfx.play()
            load_music("song-1.mp3")
        
        frametick+=1
        if frametick==20:
            frametick=0
            if frame!=len(sprites[evilstat[charindex][0]])-1:
                frame+=1
            else:
                frame=0
        pg.draw.rect(window,white,(0,200,230,120))
        
        if evilstat[charindex][6]==0:
            txt=menufont2.render("single",True,black)
        else:
            txt=menufont2.render("multi",True,black)
        window.blit(txt,(0,200))

        if evilstat[charindex][7]!=0:
            pg.draw.rect(window,white,(0,430,400,120))
            if evilstat[charindex][7]==1:
                txt=menufont2.render("knockback",True,black)
            elif evilstat[charindex][7]==2:
                txt=menufont2.render("metal",True,black)
            window.blit(txt,(0,430))

        
        txt=menufont.render(str(evilnames[charindex]),True,white)
        window.blit(txt,(0,0))
        scaled_image = pg.transform.scale(sprites[evilstat[charindex][0]][frame], (400, 400))
        flipped_img = pg.transform.flip(scaled_image, True, False)
        window.blit(flipped_img, (550,200))

        
        if left and charindex!=0:
            charindex-=1
            frame=0
            frameindex=0
            left=0
        if right and charindex!=len(evilstat)-1:
            charindex+=1
            frame=0
            frameindex=0
            right=0


    if game==-8:
        txt=menufont.render('      YOU GOT',True,white)
        window.blit(txt,titlerect2)
        scaled_image = pg.transform.scale(sprites[goodstat[roll][0]][0], (400, 400))
        window.blit(scaled_image, (550,400))
        if leftclick:
            leftclick=0
            game=-7

    if game == -9:
        pg.draw.rect(window, "white", b1)
        pg.draw.rect(window, "white", b2)
        pg.draw.rect(window, "white", b3)
        txt = menufont.render("       endless", True, "black")
        window.blit(txt, b1)
        if charlist[15]==0:
            txt = menufont.render("     boss fight", True, "black")
        else:
            txt = menufont.render("     boss fight", True, "green")
        window.blit(txt, b2)
        
        stage()
        
        
        
        click(b1, enter, -4,4)
        click(b2, enter, -4,7)

    if game==-10:
        pg.draw.rect(window,white,b4)
        txt=menufont2.render('Save',True,black)
        window.blit(txt,b4)
        pg.draw.rect(window,white,b5)
        pg.draw.rect(window,white,b6)
        txt=menufont2.render('WIPE DATA',True,red)
        window.blit(txt,b5)
        if performancemode:
            txt=valuefont.render('Performance mode',True,green)
            if leftclick and b6.collidepoint(mousex,mousey):
                performancemode=0
                leftclick=0
        else:
            txt=valuefont.render('Performance mode',True,black)
            if leftclick and b6.collidepoint(mousex,mousey):
                performancemode=1
                leftclick=0
        window.blit(txt,b6)
        if leftclick and b4.collidepoint(mousex,mousey):
            save_game()
        if leftclick and b5.collidepoint(mousex,mousey):
            wipe_save()

        pg.draw.rect(window,white,backbutton)
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0
            clicksfx.play()
            load_music("song-1.mp3")

        pg.draw.rect(window,white,(slider_x-10,slider_y-75,slider_w+70,slider_h+100))
        
        if 'music_handle_x' not in globals():
            music_handle_x = slider_x + int(pg.mixer.music.get_volume() * slider_w)

        # Handle dragging
        if leftclick and slider_x <= mousex <= slider_x + slider_w and slider_y - 10 <= mousey <= slider_y + 20:
            music_handle_x = mousex
            # convert to 0.0–1.0
            volume = (music_handle_x - slider_x) / slider_w
            pg.mixer.music.set_volume(volume)

        # Draw slider bar
        pg.draw.rect(window, (100, 100, 100), (slider_x, slider_y, slider_w, slider_h))
        # Draw handle
        pg.draw.circle(window, (200, 200, 50), (music_handle_x, slider_y + slider_h // 2), 10)

        # Label
        txt = valuefont.render(f"Music Volume: {int(pg.mixer.music.get_volume()*100)}%", True, black)
        window.blit(txt, (slider_x, slider_y - 75))

        if int(pg.mixer.music.get_volume()*100)==0:
            pg.mixer.music.set_volume(0)
        
        

    if game == -4:
        window.fill("tan")
        if not multiplayer:
            txt = menufont2.render("     SELECT CHARACTERS", True, "white")
        else:
            txt = menufont2.render(f"PLAYER {player+1}", True, "white")
            if leftclick and titlerect.collidepoint(mousex,mousey):
                leftclick=0
                if player==0:
                    player=1
                else:
                    player=0
            if down and player==0:
                player=1
                down=0
                charindex=0
            if up and player==1:
                player=0
                up=0
                charindex=0
        if showstats:
            pg.draw.rect(window,red,titlerect,10)
        window.blit(txt, titlerect)
        

        pg.draw.rect(window, "white", charb1)
        pg.draw.rect(window, "white", charb2)
        pg.draw.rect(window, "white", charb3)
        pg.draw.rect(window, "white", charb4)
        pg.draw.rect(window, "white", charb5)
        if player==1:
            if char1 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char1][0]][0], (200, 200))
                window.blit(scaled_image, charb1)

            if char2 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char2][0]][0], (200, 200))
                window.blit(scaled_image, charb2)

            if char3 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char3][0]][0], (200, 200))
                window.blit(scaled_image, charb3)

            if char4 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char4][0]][0], (200, 200))
                window.blit(scaled_image, charb4)

            if char5 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char5][0]][0], (200, 200))
                window.blit(scaled_image, charb5)

        if player==0:
            if char6 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char6][0]][0], (200, 200))
                window.blit(scaled_image, charb1)

            if char7 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char7][0]][0], (200, 200))
                window.blit(scaled_image, charb2)

            if char8 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char8][0]][0], (200, 200))
                window.blit(scaled_image, charb3)

            if char9 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char9][0]][0], (200, 200))
                window.blit(scaled_image, charb4)

            if char10 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char10][0]][0], (200, 200))
                window.blit(scaled_image, charb5)

        

        br = 675 - (charindex * 200)
        pg.draw.rect(window, "black", (650, 575, 200, 200))
        for i in range(len(charlist)):
            object = charlist[i]
            if player==1:
                if char1!=i and char2!=i and char3!=i and char4!=i and char5!=i:
                    pg.draw.rect(window, "white", (br, 600, 150, 150))
                else:
                    pg.draw.rect(window, gray, (br, 600, 150, 150))
            else:
                if char6!=i and char7!=i and char8!=i and char9!=i and char10!=i:
                    pg.draw.rect(window, "white", (br, 600, 150, 150))
                else:
                    pg.draw.rect(window, gray, (br, 600, 150, 150))
            if object == 1:
                scaled_image = pg.transform.scale(sprites[goodstat[i][0]][0], (150, 150))
                window.blit(scaled_image, (br, 600, 100, 100))
            else:
                txt = menufont.render("?", True, "black")
                window.blit(txt, (br, 600, 100, 100))
            br += 200

        if charb1.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            if player:
                char1=-1
            else:
                char6=-1
        if charb2.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            if player:
                char2=-1
            else:
                char7=-1
        if charb3.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            if player:
                char3=-1
            else:
                char8=-1
        if charb4.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            if player:
                char4=-1
            else:
                char9=-1
        if charb5.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            if player:
                char5=-1
            else:
                char10=-1
        

        if (left or (pg.Rect(0,400,150,400).collidepoint(mousex,mousey) and leftclick)) and charindex != 0:
            charindex -= 1
        if (right or (pg.Rect(1350,400,150,400).collidepoint(mousex,mousey) and leftclick)) and charindex != len(charlist) - 1:
            charindex += 1

        if player==1:
            if (enter or (leftclick and pg.Rect(675,600,150,150).collidepoint(mousex,mousey))) and charlist[charindex] != 0:
                if charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5:
                    enter = 0
                    if char1 == -1:
                        char1 = charindex
                    elif char2 == -1:
                        char2 = charindex
                    elif char3 == -1:
                        char3 = charindex
                    elif char4 == -1:
                        char4 = charindex
                    elif char5 == -1:
                        char5 = charindex

            if k1:
                if not shift and charindex != char1 and charindex != char2 and charindex != char3 and charindex != char4 and charindex != char5 and charlist[charindex]!=0:
                    char1 = charindex
                elif shift:
                    char1 = -1
            if k2:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char2 = charindex
                elif shift:
                    char2 = -1
            if k3:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char3 = charindex
                elif shift:
                    char3 = -1
            if k4:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char4 = charindex
                elif shift:
                    char4 = -1
            if k5:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char5 = charindex
                elif shift:
                    char5 = -1

            if back==1:
                char6=-1
                char7=-1
                char8=-1
                char9=-1
                char10=-1
        
        if player==0:
            if (enter or (leftclick and pg.Rect(675,600,150,150).collidepoint(mousex,mousey))) and charlist[charindex] != 0:
                if charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10:
                    enter = 0
                    if char6 == -1:
                        char6 = charindex
                    elif char7 == -1:
                        char7 = charindex
                    elif char8 == -1:
                        char8 = charindex
                    elif char9 == -1:
                        char9 = charindex
                    elif char10 == -1:
                        char10 = charindex

            if k1:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char6 = charindex
                elif shift:
                    char6 = -1
            if k2:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char7 = charindex
                elif shift:
                    char7 = -1
            if k3:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char8 = charindex
                elif shift:
                    char8 = -1
            if k4:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char9 = charindex
                elif shift:
                    char9 = -1
            if k5:
                if not shift and charindex != char6 and charindex != char7 and charindex != char8 and charindex != char9 and charindex != char10 and charlist[charindex]!=0:
                    char10 = charindex
                elif shift:
                    char10 = -1

            if back==1:
                char6=-1
                char7=-1
                char8=-1
                char9=-1
                char10=-1

        if not multiplayer:
            if (char1 != -1 or char2 != -1 or char3 != -1 or char4 != -1 or char5 != -1):
                pg.draw.rect(window,white,startbutton)
                txt=valuefont.render("START!",True,black)
                window.blit(txt,startbutton)
        else:
            if (char1 != -1 or char2 != -1 or char3 != -1 or char4 != -1 or char5 != -1) and (char6 != -1 or char7 != -1 or char8 != -1 or char9 != -1 or char10 != -1):
                pg.draw.rect(window,white,startbutton)
                txt=valuefont.render("START!",True,black)
                window.blit(txt,startbutton)

        pg.draw.rect(window,white,backbutton)
        txt=valuefont.render("back",True,black)
        window.blit(txt,backbutton)
        if backbutton.collidepoint(mousex,mousey) and leftclick:
            leftclick=0
            game=0
            clicksfx.play()
            load_music("song-1.mp3")

        if multiplayer and (space or (startbutton.collidepoint(mousex,mousey) and leftclick)) and (char1 != -1 or char2 != -1 or char3 != -1 or char4 != -1 or char5 != -1) and (char6 != -1 or char7 != -1 or char8 != -1 or char9 != -1 or char10 != -1):
            mon=0
            aimon1=0
            eff=1
            aieff1=1
            game = 1
            background=0
            ground=0
            hp1=100
            hp2=100
            choosesong(("song-9.mp3","song-8.mp3"))
            upmon=200
            upmon2=200
            cannoncd=0
            cannoncd2=0
            goods.clear()
            evils.clear()
            char1cd = charcd[char1]
            char2cd = charcd[char2]
            char3cd = charcd[char3]
            char4cd = charcd[char4]
            char5cd = charcd[char5]
            char6cd = charcd[char6]
            char7cd = charcd[char7]
            char8cd = charcd[char8]
            char9cd = charcd[char9]
            char10cd = charcd[char10]
            

        if not multiplayer:
            cannoncd=0
            if (space or (startbutton.collidepoint(mousex,mousey) and leftclick)) and (char1 != -1 or char2 != -1 or char3 != -1 or char4 != -1 or char5 != -1):
                mon = 0
                aimon1 = 0
                aimon2 = 0
                game = 1
                background=0
                ground=0
                eff = 1
                upmon=200
                hp1 = 100
                hp2 = 100
                goods.clear()
                evils.clear()
                char1cd = charcd[char1]
                char2cd = charcd[char2]
                char3cd = charcd[char3]
                char4cd = charcd[char4]
                char5cd = charcd[char5]
                char6cd = charcd[char6]
                char7cd = charcd[char7]
                char8cd = charcd[char8]
                char9cd = charcd[char9]
                char10cd = charcd[char10]
                leftclick=0
                load_music("song-3.mp3")
                evilarmy.clear()
                for i in range(len(evilcost)):
                    if evilcost[i] != -1:
                        evilarmy.append(i)
                hp1 = 100
                hp2 = 100
                goods.clear()
                evils.clear()
                char1cd = charcd[char1]
                char2cd = charcd[char2]
                char3cd = charcd[char3]
                char4cd = charcd[char4]
                char5cd = charcd[char5]
                leftclick=0
                
                if not endless and not campaign:
                    if difficulty==1:
                        choosesong(("song-3.mp3","song-4.mp3"))
                        aieff1 = 0.6
                        aieff2 = 0.3
                    if difficulty==2:
                        load_music("song-7.mp3")
                        aieff1 = 1
                        aieff2 = 0.6
                    if difficulty==3:
                        choosesong(("song-5.mp3","song-6.mp3"))
                        aieff1 = 1.5
                        aieff2 = 1
                    if difficulty==4:
                        load_music("song-11.mp3")
                        aieff1 = 1
                        aieff2 = 0.6
                        background=1
                        ground=1
                        hp2=300
                    if difficulty==5:
                        aieff1 = 0
                        aieff2 = 3
                        evilarmy=[8]
                    if difficulty==6:
                        aieff1 = 0.5
                        aieff2 = 1.5
                        evilarmy=[0,3]
                    if difficulty==7:
                        aieff1=0.7
                        aieff2=1
                        evilarmy=[1,2,9]
                    if difficulty==8:
                        aieff1=0
                        aieff2=6
                        evilarmy=[1,9]
                    if difficulty==9:
                        aieff1=1
                        aieff2=1
                        evilarmy=[4,5]
                    if difficulty==10:
                        aieff1=0.5
                        aieff2=2
                        evilarmy=[0,4,5,6,7]
                    if difficulty==11:
                        aieff1=2
                        aieff2=0

                if endless:
                    
                    aieff1=1
                    aieff2=0.6
                    hp2=9999999999999999999
                timer=0
                if campaign:
                    difficulty=1
                    endless=0
                    if level==0:
                        evilarmy=[0]
                        aieff1=0.3
                        aieff2=0
                        hp2=10
                    if level==1:
                        evilarmy=[0,1]
                        aieff1=0.3
                        aieff2=0.1
                        hp2=20
                    if level==2:
                        evilarmy=[0,1]
                        aieff1=0.5
                        aieff2=0.15
                        hp2=40
                    if level==3:
                        evilarmy=[0,1,2]
                        aieff1=0.5
                        aieff2=0.3
                        hp2=80
                    if level==4:
                        evilarmy=[0,1,2,3]
                        aieff1=0.6
                        aieff2=0.35
                        hp2=100
                    if level==5:
                        evilarmy=[0,1,2,3,4,5]
                        aieff1=0.7
                        aieff2=0.4
                        hp2=100
                    if level==6:
                        evilarmy=[0,1,2,3,4,5,6,7]
                        aieff1=0.8
                        aieff2=0.45
                        hp2=100
                    if level==7:
                        evilarmy=[0,1,2,3,4,5,6,7,8,9]
                        aieff1=1
                        aieff2=0.5
                        hp2=100
                    if level==8:
                        evilarmy=[0,1,2,3,4,5,6,7,8,9]
                        aieff1=0.5
                        aieff2=0.25
                        hp2=300
                        background=2
                    if level==9:
                        background=2
                        evilarmy=[3,6]
                        aieff1=0.7
                        aieff2=0.7
                        hp2=100
                        load_music("song-12.mp3")
                    if level==10:
                        background=2
                        evilarmy=[2,9,11,6,11]
                        aieff1=0.5
                        aieff2=1
                        hp2=120
                        load_music("song-12.mp3")
                    if level==11:
                        background=2
                        evilarmy=[11,12,5]
                        aieff1=1
                        aieff2=1.5
                        hp2=140
                        load_music("song-12.mp3")
                    if level==12:
                        background=2
                        evilarmy=[11,12,11]
                        aieff1=1
                        aieff2=1.5
                        hp2=160
                        load_music("song-13.mp3")
                    if level==13:
                        background=2
                        evilarmy=[11,12,11]
                        aieff1=1
                        aieff2=1
                        hp2=180
                        load_music("song-14.mp3")
                    if level==14:
                        background=2
                        evilarmy=[11,12,13]
                        aieff1=1
                        aieff2=1.5
                        hp2=200
                        load_music("song-12.mp3")

    if game == 1:
        if performancemode:
            window.fill(blue)
        else:
            window.blit(sprites[100][background],(0,0))
        

        if char1 != -1 and char1cd < charcd[char1]:
            char1cd += 1
        if char2 != -1 and char2cd < charcd[char2]:
            char2cd += 1
        if char3 != -1 and char3cd < charcd[char3]:
            char3cd += 1
        if char4 != -1 and char4cd < charcd[char4]:
            char4cd += 1
        if char5 != -1 and char5cd < charcd[char5]:
            char5cd += 1

        if multiplayer:
            if char6 != -1 and char6cd < charcd[char6]:
                char6cd += 1
            if char7 != -1 and char7cd < charcd[char7]:
                char7cd += 1
            if char8 != -1 and char8cd < charcd[char8]:
                char8cd += 1
            if char9 != -1 and char9cd < charcd[char9]:
                char9cd += 1
            if char10 != -1 and char10cd < charcd[char10]:
                char10cd += 1

        mon += eff
        aimon1 += aieff1
        if not aioff and not multiplayer:
            aimon2 += aieff2
            if random.randint(0, 150) == 10:
                char = random.choice(evilarmy)   # pick random unit index directly
                
                if aimon1 >= evilcost[char]:
                    
                    
                    evils.append(evil(*evilstat[char]))
                    aimon1 -= evilcost[char]

            if aidesiredunit == -1:
                aidesiredunit = random.choice(evilarmy)
            elif aimon2 >= evilcost[aidesiredunit] and random.randint(0,2)==2:
                
                
                evils.append(evil(*evilstat[aidesiredunit]))
                aimon2 -= evilcost[aidesiredunit]
                aidesiredunit=-1

        if e and manualenemyplace:
            evils.append(evil(*evilstat[enemytype-1]))
        
        if performancemode:
            pg.draw.rect(window, "green", (0, 600, 1500, 200))
        else:
            window.blit(sprites[101][ground],(0,600))

        if fire:
            fire=0
            if performancemode:
                pg.draw.rect(window,yellow,(1250,225,50,200))
            else:
                if cannontype==0:
                    window.blit(sprites[103][1],(1250,25))
        elif cannontype==0 and not performancemode:
            window.blit(sprites[103][0],(1250,25))

        if multiplayer:
            if fire2:
                fire2=0
                if performancemode:
                    pg.draw.rect(window,yellow,(200,225,50,200))
                else:
                    if cannontype==0:
                        img = sprites[103][1]
                        flipped_img = pg.transform.flip(img, True, False)
                        window.blit(flipped_img, (50,25))

            elif cannontype==0 and not performancemode:
                img = sprites[103][0]
                flipped_img = pg.transform.flip(img, True, False)
                window.blit(flipped_img,(50,25))

        if difficulty==4:
            if timer/16%(60*15)==0:
                fire2=15
            if fire2!=0:
                window.blit(sprites[104][0],(50,25))
                fire2-=1
                if fire2==0:
                    if (timer/16)>(60*15):
                        #template=evilstat[10]
                        #a,b,c,d,e,f,g,h,i,j=template
                        #evils.append(evil(a,b,c,d,e,f,g,h,i,j))
                        evils.append(evil(*evilstat[10]))
            else:
                window.blit(sprites[104][1],(50,25))

        if not performancemode:
            window.blit(sprites[102][0],t1)
            window.blit(sprites[102][0],t2)
        else:
            pg.draw.rect(window, "gray", t1)
            pg.draw.rect(window, "gray", t2)

        

        txt = valuefont2.render(str(hp1), True, black)
        window.blit(txt, (t1.x+10,t1.y+12))
        if hp2>1000:
            txt = valuefont2.render('Infinite', True, red)
        else:
            txt = valuefont2.render(str(hp2), True, black)
        window.blit(txt, (t2.x+10,t2.y+12))
        if background!=2:
            txt = valuefont.render(f"{round(mon)}$", True, "black")
        else:
            txt = valuefont.render(f"{round(mon)}$", True, white)
        window.blit(txt, (1350, 0, 1, 1))

        if multiplayer:
            txt = valuefont.render(f"{round(aimon1)}$", True, "black")
            window.blit(txt, (0, 0, 1, 1))

        if not multiplayer:
            drawback(char1, char1cd, gb1)
            drawback(char2, char2cd, gb2)
            drawback(char3, char3cd, gb3)
            drawback(char4, char4cd, gb4)
            drawback(char5, char5cd, gb5)
        else:
            drawback2(char6, char6cd, multibutton[2])
            drawback2(char7, char7cd, multibutton[3])
            drawback2(char8, char8cd, multibutton[4])
            drawback2(char9, char9cd, multibutton[5])
            drawback2(char10, char10cd, multibutton[6])
            drawback(char1, char1cd, multibutton[7])
            drawback(char2, char2cd, multibutton[8])
            drawback(char3, char3cd, multibutton[9])
            drawback(char4, char4cd, multibutton[10])
            drawback(char5, char5cd, multibutton[11])

        if not multiplayer:
            if mon>=upmon:
                pg.draw.rect(window,white,gb6)
                if enter or (leftclick and gb6.collidepoint(mousex,mousey)):
                    mon-=upmon
                    eff*=1.1
                    upmon*=2
                    enter=0
            else:
                pg.draw.rect(window,gray,gb6)
        else:
            if mon>=upmon:
                pg.draw.rect(window,white,multibutton[13])
                if p or (leftclick and multibutton[13].collidepoint(mousex,mousey)):
                    mon-=upmon
                    eff*=1.1
                    upmon*=2
                    p=0
            else:
                pg.draw.rect(window,gray,multibutton[13])

            if aimon1>=upmon2:
                pg.draw.rect(window,white,multibutton[0])
                if q or (leftclick and multibutton[0].collidepoint(mousex,mousey)):
                    aimon1-=upmon2
                    aieff1*=1.1
                    upmon2*=2
                    q=0
            else:
                pg.draw.rect(window,gray,multibutton[0])

        
        if not multiplayer:
            txt=menufont2.render(str(upmon),True,black)
            window.blit(txt,gb6)
        else:
            txt=valuefont.render(str(upmon),True,black)
            window.blit(txt,multibutton[13])
            txt=valuefont.render(str(upmon2),True,black)
            window.blit(txt,multibutton[0])

        
        if not multiplayer:
            if char1 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char1][0]][0], (150, 150))
                window.blit(scaled_image, gb1)

                txt = valuefont.render(f"{charcost[char1]}$", True, "black")
                window.blit(txt, (gb1.x, gb1.y + 100, 1, 1))

            if char2 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char2][0]][0], (150, 150))
                window.blit(scaled_image, gb2)

                txt = valuefont.render(f"{charcost[char2]}$", True, "black")
                window.blit(txt, (gb2.x, gb2.y + 100, 1, 1))

            if char3 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char3][0]][0], (150, 150))
                window.blit(scaled_image, gb3)

                txt = valuefont.render(f"{charcost[char3]}$", True, "black")
                window.blit(txt, (gb3.x, gb3.y + 100, 1, 1))

            if char4 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char4][0]][0], (150, 150))
                window.blit(scaled_image, gb4)

                txt = valuefont.render(f"{charcost[char4]}$", True, "black")
                window.blit(txt, (gb4.x, gb4.y + 100, 1, 1))

            if char5 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char5][0]][0], (150, 150))
                window.blit(scaled_image, gb5)

                txt = valuefont.render(f"{charcost[char5]}$", True, "black")
                window.blit(txt, (gb5.x, gb5.y + 100, 1, 1))
        else:
            pg.draw.line(window,red,(750.5,600),(750.5,800),8)

            if char1 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char1][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[7])

                txt = valuefont2.render(f"{charcost[char1]}$", True, "black")
                window.blit(txt, (multibutton[7].x, multibutton[7].y + 60, 1, 1))

            if char2 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char2][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[8])

                txt = valuefont2.render(f"{charcost[char2]}$", True, "black")
                window.blit(txt, (multibutton[8].x, multibutton[8].y + 60, 1, 1))

            if char3 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char3][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[9])

                txt = valuefont2.render(f"{charcost[char3]}$", True, "black")
                window.blit(txt, (multibutton[9].x, multibutton[9].y + 60, 1, 1))

            if char4 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char4][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[10])

                txt = valuefont2.render(f"{charcost[char4]}$", True, "black")
                window.blit(txt, (multibutton[10].x, multibutton[10].y + 60, 1, 1))

            if char5 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char5][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[11])
                
                txt = valuefont2.render(f"{charcost[char5]}$", True, "black")
                window.blit(txt, (multibutton[11].x, multibutton[11].y + 60, 1, 1))


            if char6 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char6][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[2])

                txt = valuefont2.render(f"{charcost[char6]}$", True, "black")
                window.blit(txt, (multibutton[2].x, multibutton[2].y + 60, 1, 1))

            if char7 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char7][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[3])

                txt = valuefont2.render(f"{charcost[char7]}$", True, "black")
                window.blit(txt, (multibutton[3].x, multibutton[3].y + 60, 1, 1))

            if char8 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char8][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[4])

                txt = valuefont2.render(f"{charcost[char8]}$", True, "black")
                window.blit(txt, (multibutton[4].x, multibutton[4].y + 60, 1, 1))

            if char9 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char9][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[5])

                txt = valuefont2.render(f"{charcost[char9]}$", True, "black")
                window.blit(txt, (multibutton[5].x, multibutton[5].y + 60, 1, 1))

            if char10 != -1:
                scaled_image = pg.transform.scale(sprites[goodstat[char10][0]][0], (100, 100))
                window.blit(scaled_image, multibutton[6])
                
                txt = valuefont2.render(f"{charcost[char10]}$", True, "black")
                window.blit(txt, (multibutton[6].x, multibutton[6].y + 60, 1, 1))

        if not multiplayer:
            create(char1, gb1, k1, char1cd)
            create(char2, gb2, k2, char2cd)
            create(char3, gb3, k3, char3cd)
            create(char4, gb4, k4, char4cd)
            create(char5, gb5, k5, char5cd)
        else:
            create(char1, multibutton[7], k6, char1cd)
            create(char2, multibutton[8], k7, char2cd)
            create(char3, multibutton[9], k8, char3cd)
            create(char4, multibutton[10], k9, char4cd)
            create(char5, multibutton[11], k0, char5cd)
            create2(char6, multibutton[2], k1, char6cd)
            create2(char7, multibutton[3], k2, char7cd)
            create2(char8, multibutton[4], k3, char8cd)
            create2(char9, multibutton[5], k4, char9cd)
            create2(char10, multibutton[6],k5, char10cd)

        for i in goods:
            i.attack()
            i.towerattack()
            i.tempmove()
            i.draw()
            i.ded()

        for i in evils:
            i.attack()
            i.towerattack()
            i.tempmove()
            i.draw()
            i.ded()

        if not multiplayer:
            if cannoncd==(60*30):
                pg.draw.rect(window,white,gb7)
                pg.draw.rect(window,green,gb7,3)
                if space or (leftclick and gb7.collidepoint(mousex,mousey)):
                    space=0
                    cannoncd=0
                    fire=1
                    pg.draw.rect(window,red,(250,575,1000,25))
                    if cannontype==0:
                        for i in evils:
                            i.x-=50
                            i.Rect.x-=50
                            i.hp-=5
                            i.atick=0

            else:
                pg.draw.rect(window,gray,gb7)
                if cannoncd!=0:
                    pg.draw.rect(window,white,(gb7.x,gb7.y,(cannoncd/(60*30))*150,gb7.height))
                cannoncd+=1

            txt=valuefont.render('cannon',True,black)
            window.blit(txt,gb7)


        else:
            if cannoncd==(60*30):
                pg.draw.rect(window,white,multibutton[12])
                pg.draw.rect(window,green,multibutton[12],3)
                if p or (leftclick and multibutton[12].collidepoint(mousex,mousey)):
                    p=0
                    cannoncd=0
                    fire=1
                    pg.draw.rect(window,red,(250,575,1000,25))
                    if cannontype==0:
                        for i in evils:
                            i.x-=50
                            i.Rect.x-=50
                            i.hp-=5
                
            else:
                pg.draw.rect(window,gray,multibutton[12])
                if cannoncd!=0:
                    pg.draw.rect(window,white,(multibutton[12].x,multibutton[12].y,(cannoncd/(60*30))*100,multibutton[12].height))
                cannoncd+=1

            txt=valuefont2.render('cannon',True,black)
            window.blit(txt,multibutton[12])

            if cannoncd2==(60*30):
                pg.draw.rect(window,white,multibutton[1])
                pg.draw.rect(window,green,multibutton[1],3)
                if q or (leftclick and multibutton[1].collidepoint(mousex,mousey)):
                    q=0
                    cannoncd2=0
                    fire2=1
                    pg.draw.rect(window,blue,(250,575,1000,25))
                    if cannontype==0:
                        for i in goods:
                            i.x+=50
                            i.Rect.x+=50
                            i.hp-=5
                
            else:
                pg.draw.rect(window,gray,multibutton[1])
                if cannoncd2!=0:
                    pg.draw.rect(window,white,(multibutton[1].x,multibutton[1].y,(cannoncd2/(60*30))*100,multibutton[1].height))
                cannoncd2+=1

            txt=valuefont2.render('cannon',True,black)
            window.blit(txt,multibutton[1])


        timer+=16
        
        if endless:
            
            if timer%(16*60*20)==0:
                aieff1+=0.2
                aieff2+=0.1
            txt=valuefont.render(str(round((timer/1000),2)),True,black)
            window.blit(txt,(0,0))

        if campaign:
            if background!=2:
                txt=valuefont.render(f"Level {level+1}",True,black)
            else:
                txt=valuefont.render(f"Level {level+1}",True,white)
            window.blit(txt,(0,0))
            if level==8:
                if timer==(16*60*5):
                    evils.append(evil(9,0.2,600,1000,200,100,1,0,3,6))
            if level==9:
                if timer%(16*60*15)==0:
                    evils.append(evil(*evilstat[11]))
            if level==13:
                if timer%(16*60*15)==0:
                    evils.append(evil(*evilstat[13]))
            

        if hp1<=0 or hp2<=0:
            
            mon = 0
            aimon1 = 0
            aimon2 = 0
            goods.clear()
            evils.clear()
            char1cd = 0
            char2cd = 0
            char3cd = 0
            char4cd = 0
            char5cd = 0
            
                
            
            
            
            random.seed()

        if hp1<=0:
            game=-6
        if hp2<=0:
            game=-5
            if not campaign:
                box+=1
            if campaign:
                if level<=8:
                    level+=1
                    charlist[level]=1
                elif level<=13:
                    if level==9:
                        charlist[16]=1
                    if level==12:
                        charlist[17]=1
                    level+=1
                elif level==14:
                    charlist[18]=1
            elif difficulty==4:
                charlist[15]=1

            elif 5<=difficulty<=11:
                box+=2
            save_game()



    if game==-5 or game==-6:
        window.fill(white)
        if game==-5:
            if not multiplayer:
                txt=menufont.render('YOU WIN!',True,black)
            else:
                txt=menufont.render('player 2 wins',True,black)
            
        if game==-6:
            if not multiplayer:
                txt=menufont.render('YOU LOSE!',True,black)
            else:
                txt=menufont.render('player 2 wins',True,black)
            if endless:
                txt=menufont.render(f"Time:{round(((timer/1000)),2)}")
                window.blit(txt,(300,600))
        
        
        window.blit(txt,titlerect)
        pg.draw.rect(window,gray,backtomenurect)
        txt=menufont2.render("back to menu",True,black)
        window.blit(txt,backtomenurect)
        click(backtomenurect,enter,0)

    if showfps:
        fps=round(clock.get_fps(),2)
        txt=valuefont2.render(f"FPS:{fps}",True,white)
        window.blit(txt,(0,0))
    autosave+=1
    if autosave==(60*45):
        autosave=0
        save_game()
    pg.display.update()
    clock.tick(60)
    