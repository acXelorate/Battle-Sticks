import pygame as pg      
from random import randint,seed     #trenutno radim na balancing i spawnovanje protivnickog tima

seed()

pg.init()
pg.font.init()

asciifont = pg.font.SysFont("Segoe UI Emoji", 80)
menufont=pg.font.SysFont("Arial",100)
valuefont=pg.font.SysFont("Arial",30)
upgradefont=pg.font.SysFont("Arial",70)



pg.mixer_music.load("song-1.mp3")
pg.mixer_music.play(-1)

#cheats
time=0
eff=1
aieff=1
showhp=0

#
frame1=[0,pg.image.load("1-1.png"),pg.image.load("1-2.png"),pg.image.load("1-3.png"),pg.image.load("1-4.png")]
frame2=[0,pg.image.load("2-1.png"),pg.image.load("2-2.png"),pg.image.load("2-3.png"),pg.image.load("2-4.png")]
frame3=[0,pg.image.load("3-1.png"),pg.image.load("3-2.png"),pg.image.load("3-3.png"),pg.image.load("3-4.png")]
frame4=[0,pg.image.load("4-1.png"),pg.image.load("4-2.png"),pg.image.load("4-3.png"),pg.image.load("4-4.png")]
frame5=[0,pg.image.load("5-1.png"),pg.image.load("5-2.png"),pg.image.load("5-3.png"),pg.image.load("5-4.png")]
frame6=[0,pg.image.load("6-1.png"),pg.image.load("6-2.png"),pg.image.load("6-3.png"),pg.image.load("6-4.png")]
frame7=[0,pg.image.load("7-1.png"),pg.image.load("7-2.png"),pg.image.load("7-3.png"),pg.image.load("7-4.png")]
frame8=[0,pg.image.load("8-1.png"),pg.image.load("8-2.png"),pg.image.load("8-3.png"),pg.image.load("8-4.png")]
frame9=[0,pg.image.load("9-1.png"),pg.image.load("9-2.png"),pg.image.load("9-3.png"),pg.image.load("9-4.png")]
frame10=[0,pg.image.load("0-1.png"),pg.image.load("0-2.png"),pg.image.load("0-3.png"),pg.image.load("0-4.png")]
frame11=[0,pg.image.load("11-1.png"),pg.image.load("11-2.png"),pg.image.load("11-3.png"),pg.image.load("11-4.png"),pg.image.load("11-5.png")]

pg.display.set_caption("BATTLE STICKS","1-1.png")

diff=0
isboss=0

easy=0
medium=0
hard=0
brutal=0
boss=0

def distrop(x,y,col1,col2,txt):
    pg.draw.line(window,col2,(x-75,y-75),(x,y),10)
    pg.draw.line(window,col2,(x+75,y-75),(x,y),10)
    pg.draw.circle(window,col1,(x,y),50)
    if txt!="💀":
        text_surface = menufont.render(str(txt), False, col2)   
        window.blit(text_surface, (x-30,y-55))
    else:
        text_surface = asciifont.render(str(txt), False, col2)
        window.blit(text_surface, (x-55,y-40))


def trophy():
    global easy
    global medium
    global hard
    global brutal
    global aieff
    if aieff==0.5:
        easy=1
    if aieff==1:
        medium=1
    if aieff==1.5:
        hard=1
    if aieff>=2:
        brutal=1

hp1=0
hp2=0
hp11=100
hp22=100

prevvol=100
volcd=0

h1=100
h2=200
h3=300
h4=400
h5=500
h6=600
h7=700
h8=800
h9=900
h10=1000

ccp1=0                           #character price
ccp2=0
ccp3=0
ccp4=0
ccp5=0
ccp6=0
ccp7=0
ccp7=0
ccp8=0
ccp9=0
ccp10=0

width=1280
height=800

monbr=0
mon=0


aimon=0

cd=0
upcd=0


leftclick=0

summons1=[]
summons2=[]


summons1rect=[]
summons2rect=[]

MB1=pg.Rect(10,height/2-200,670,100)
MB2=pg.Rect(10,height/2,670,100)
MB3=pg.Rect(10,height/2+200,670,100)
MB4=pg.Rect(690,height/2-200,670,100)
MB5=pg.Rect(690,height/2,670,100)
MB6=pg.Rect(690,height/2+200,670,100)

LB1=pg.Rect(50,650,100,100)     #loadout button (1-10)
LB2=pg.Rect(160,650,100,100)
LB3=pg.Rect(270,650,100,100)
LB4=pg.Rect(380,650,100,100)
LB5=pg.Rect(490,650,100,100)
LB6=pg.Rect(600,650,100,100)
LB7=pg.Rect(710,650,100,100)
LB8=pg.Rect(820,650,100,100)
LB9=pg.Rect(930,650,100,100)
LB10=pg.Rect(1040,650,100,100)

BB=pg.Rect(1180,0,100,100)

SB=pg.Rect(0,0,100,100)

LLB1=pg.Rect(50,150,200,200)
LLB2=pg.Rect(300,150,200,200)
LLB3=pg.Rect(550,150,200,200)
LLB4=pg.Rect(800,150,200,200)
LLB5=pg.Rect(1050,150,200,200)

t1=pg.Rect(1030,200,200,400)
t2=pg.Rect(30,200,200,400)

btmb=pg.Rect(500,500,500,100)

cc1=0
cc2=0
cc3=0
cc4=0
cc5=0
cc6=0
cc7=0
cc8=0
cc9=0
cc10=0

def dif(button,aief):
    global aieff
    global leftclick
    if button.collidepoint(mousex,mousey) and leftclick:
        aieff=aief

def disport(sprite,slot,scale):
    global frame1
    global frame2
    global frame3
    global frame4
    global frame5
    global frame6
    global frame7
    global frame8
    global frame9
    global frame10
    global frame11
    
    if sprite==1:
        img=pg.transform.scale(frame1[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==2:
        img=pg.transform.scale(frame2[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==3:
        img=pg.transform.scale(frame3[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==4:
        img=pg.transform.scale(frame4[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==5:
        img=pg.transform.scale(frame5[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==6:
        img=pg.transform.scale(frame6[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==7:
        img=pg.transform.scale(frame7[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==8:
        img=pg.transform.scale(frame8[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==9:
        img=pg.transform.scale(frame9[1],(100*scale,100*scale))
        window.blit(img,slot)
    elif sprite==10:
        img=pg.transform.scale(frame10[1],(100*scale,100*scale))
        window.blit(img,slot)


def create(LB,key,cc):       #pravljenje player 1(desna strana) likove

    global cd
    global mon
    global h1
    global h2
    global h3
    global h4
    global h5
    global h6
    global h7
    global h8
    global h9
    global h10                                                       

    if (LB.collidepoint(mousex,mousey) and leftclick) or keys[key]:   #statovi
        if cd==10:                                                    #sprite,attack speed,movement speed,hp,dmg,range,tick,type,sprite
                                                                    
            if cc==1 and mon>=h1:
                mon-=h1
                summons1.append(summon(1,60,1.5,15,3,1,0,0,1,1))
                summons1rect.append(pg.Rect(1030,500,99,100))
                cd=0

            if cc==2 and mon>=h2:
                mon-=h2
                summons1.append(summon(2,100,1,35,1,1,0,1,1,1))     #treba da splashuje
                summons1rect.append(pg.Rect(1030,499.9,98,100.1))
                cd=0

            if cc==3 and mon>=h3:
                mon-=h3
                summons1.append(summon(3,30,1.5,5,5,10,0,0,1,1))
                summons1rect.append(pg.Rect(1030,499.8,97,101.2))      #,sprite,attack speed,movement speed,hp,dmg,range,tick,type.sprite
                cd=0

            if cc==4 and mon>=h4:
                mon-=h4
                summons1.append(summon(4,100,1,5,10,150,0,0,1,1))
                summons1rect.append(pg.Rect(1030,499.7,96,101.3))
                cd=0

            if cc==5 and mon>=h5:
                mon-=h5
                summons1.append(summon(5,7,5,7,1,1,0,0,1,1))
                summons1rect.append(pg.Rect(1030,499.6,95,101.4))
                cd=0

            if cc==6 and mon>=h6:
                mon-=h6
                summons1.append(summon(6,60,1.5,20,5,10,0,1,1,1)) #treba da splashuje
                summons1rect.append(pg.Rect(1030,499.5,94,101.5))
                cd=0

            if cc==7 and mon>=h7:
                mon-=h7
                summons1.append(summon(7,80,1.2,20,30,10,0,0,1,1)) 
                summons1rect.append(pg.Rect(1030,499.4,93,101.6))      #,sprite,attack speed,movement speed,hp,dmg,range,attack tick,type,sprite
                cd=0

            if cc==8 and mon>=h8:
                mon-=h8
                summons1.append(summon(8,80,0.8,20,20,200,0,0,1,1))
                summons1rect.append(pg.Rect(1030,499.3,92,101.7))
                cd=0

            if cc==9 and mon>=h9:
                mon-=h9
                summons1.append(summon(9,100,0.501,75,50,1,0,1,1,1)) #treba da splashuje
                summons1rect.append(pg.Rect(1030,499.2,91,101.8))
                cd=0

            if cc==10 and mon>=h10:
                mon-=h10
                summons1.append(summon(10,1000,0.501,50,1000,200,0,1,1,1)) #treba da splashuje
                summons1rect.append(pg.Rect(1030,499.1,90,101.8))
                cd=0

def create2(LB,key,cc):       #pravljenje player 2(leva strana) likove

    global cd
    global aimon
    global h1
    global h2
    global h3
    global h4
    global h5
    global h6
    global h7
    global h8
    global h9
    global h10                                                       

    if (LB.collidepoint(mousex,mousey) and leftclick) or keys[key]:   #statovi
        if cd==10:                                                    #sprite,attack speed,movement speed,hp,dmg,range,tick,type,sprite
                                                                    
            if cc==1 and aimon>=h1:
                aimon-=h1
                summons2.append(summon(1,60,1.5,15,3,1,0,0,1,1))
                summons2rect.append(pg.Rect(30,500,99,100))
                cd=0

            if cc==2 and aimon>=h2:
                aimon-=h2
                summons2.append(summon(2,100,1,35,1,1,0,1,1,1))     #treba da splashuje
                summons2rect.append(pg.Rect(30,499.9,98,100.1))
                cd=0

            if cc==3 and aimon>=h3:
                aimon-=h3
                summons2.append(summon(3,30,1.5,5,5,10,0,0,1,1))
                summons2rect.append(pg.Rect(30,499.8,97,101.2))      #,sprite,attack speed,movement speed,hp,dmg,range,tick,type.sprite
                cd=0

            if cc==4 and aimon>=h4:
                aimon-=h4
                summons2.append(summon(4,100,1,5,10,150,0,0,1,1))
                summons2rect.append(pg.Rect(30,499.7,96,101.3))
                cd=0

            if cc==5 and aimon>=h5:
                aimon-=h5
                summons2.append(summon(5,7,5,7,1,1,0,0,1,1))
                summons2rect.append(pg.Rect(30,499.6,95,101.4))
                cd=0

            if cc==6 and aimon>=h6:
                aimon-=h6
                summons2.append(summon(6,60,1.5,20,5,10,0,1,1,1)) #treba da splashuje
                summons2rect.append(pg.Rect(30,499.5,94,101.5))
                cd=0

            if cc==7 and aimon>=h7:
                aimon-=h7
                summons2.append(summon(7,80,1.2,20,30,10,0,0,1,1)) 
                summons2rect.append(pg.Rect(30,499.4,93,101.6))      #,sprite,attack speed,movement speed,hp,dmg,range,attack tick,type,sprite
                cd=0

            if cc==8 and aimon>=h8:
                aimon-=h8
                summons2.append(summon(8,80,0.8,20,20,200,0,0,1,1))
                summons2rect.append(pg.Rect(30,499.3,92,101.7))
                cd=0

            if cc==9 and aimon>=h9:
                aimon-=h9
                summons2.append(summon(9,100,0.501,75,50,1,0,1,1,1)) #treba da splashuje
                summons2rect.append(pg.Rect(30,499.2,91,101.8))
                cd=0

            if cc==10 and aimon>=h10:
                aimon-=h10
                summons2.append(summon(10,1000,0.501,50,1000,200,0,1,1,1)) #treba da splashuje
                summons2rect.append(pg.Rect(30,499.1,90,101.8))
                cd=0






def unselect(Button,var):
    global leftclick
    
    if Button.collidepoint(mousex,mousey) and leftclick:
        var=0
        leftclick=0
        
        

def selchar(lb,k,r):
    global leftclick
    global ccp1
    global ccp2
    global ccp3
    global ccp4
    global ccp5 
    global cc1
    global cc2
    global cc3
    global cc4                                                  
    global cc5                                               #selectovanje charactera(cx je od funkcije,cc1 je da li ti je u loadout)
    c1=cc1                                                          
    c2=cc2
    c3=cc3
    c4=cc4
    c5=cc5
    var=0
    if c1!=r and c2!=r and c3!=r and c4!=r and c5!=r:
        var=1
    if   var and (leftclick and lb.collidepoint(mousex,mousey)) or keys[k] and var :
        if c1==0:
            c1=r
            ccp1=r*100
            
        elif c2==0:
            c2=r
            ccp2=r*100
            
        elif c3==0:
            c3=r
            ccp3=r*100
            
        elif c4==0:
            c4=r
            ccp4=r*100
            
        elif c5==0:
            c5=r
            ccp5=r*100
            
        leftclick=0
            
    cc1=c1
    cc2=c2
    cc3=c3
    cc4=c4
    cc5=c5

def selchar2(lb,k,r):
    global leftclick
    global ccp6
    global ccp7
    global ccp8
    global ccp9
    global ccp10 
    global cc6
    global cc7
    global cc8
    global cc9                                                  
    global cc10                                               #selectovanje charactera(cx je od funkcije,cc1 je da li ti je u loadout)
    c1=cc6                                                          
    c2=cc7
    c3=cc8
    c4=cc9
    c5=cc10
    var=0
    if c1!=r and c2!=r and c3!=r and c4!=r and c5!=r:
        var=1
    if   var and (leftclick and lb.collidepoint(mousex,mousey)) or keys[k] and var :
        if c1==0:
            c1=r
            ccp6=r*100
            
        elif c2==0:
            c2=r
            ccp7=r*100
            
        elif c3==0:
            c3=r
            ccp8=r*100
            
        elif c4==0:
            c4=r
            ccp9=r*100
            
        elif c5==0:
            c5=r
            ccp10=r*100
            
        leftclick=0
            
    cc6=c1
    cc7=c2
    cc8=c3
    cc9=c4
    cc10=c5



class summon:
    def __init__(self,sprite,aspeed,mspeed,hp,dmg,range,atick,atype,frametick,frametick2): #cost, button nisam siguran
#        self.side=side
        self.sprite=sprite
#        self.cost=cost
        self.aspeed=aspeed
        self.mspeed=mspeed
        self.hp=hp
        self.dmg=dmg
        self.range=range
        self.atick=atick
        self.atype=atype
        self.frametick=frametick
        self.frametick2=frametick2
#        self.button=button
#    def create(self):



game=0
leftclick=0



window=pg.display.set_mode((width,height))
while True:
    for event in pg.event.get():
        if event.type==pg.QUIT:
            quit()
        
        if event.type==pg.MOUSEBUTTONDOWN:
            if event.button==1:
                leftclick=1
                
            else:
                leftclick=0
        else:
            leftclick=0



    keys=pg.key.get_pressed()
    if keys[pg.K_ESCAPE]:
        game=0
        pg.mixer_music.load("song-1.mp3")
        pg.mixer_music.play(-1)
    
    
    
    mousex,mousey=pg.mouse.get_pos()

    if game==0:                                                                 #main menu (drawovanje i to)
        window.fill((0,100,150))
        
        if easy:
            distrop(100,100,"brown","green",3)
        if medium:
            distrop(300,100,"gray","yellow",2)
        if hard:
            distrop(1000,100,"yellow","blue",1)
        if brutal:
            distrop(1200,100,"black","red","💀")
        if boss:
            distrop(width/2-50,100,"white","black","⭐")

        pg.draw.rect(window,"white",MB1)
        pg.draw.rect(window,"white",MB2)
        pg.draw.rect(window,"white",MB3)
        pg.draw.rect(window,"white",MB4)
        pg.draw.rect(window,"white",MB5)
        pg.draw.rect(window,"white",MB6)


        text_surface = menufont.render('Battle Sticks', False, (0, 0, 0))
        window.blit(text_surface, (width/2-200,height/2-400))

        text_surface = menufont.render('SINGLEPLAYER', False, (0, 0, 0))
        window.blit(text_surface, (10,height/2-200))

        text_surface = menufont.render('Insert Command', False, (0, 0, 0))
        window.blit(text_surface, (10,height/2))

        text_surface = menufont.render('Settings', False, (0, 0, 0))
        window.blit(text_surface, (10,height/2+200))

        if easy and medium and hard and brutal:
            text_surface = menufont.render('BOSS FIGHT', False, (255, 0, 0))
            window.blit(text_surface, (690,height/2))
            if (MB5.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_b]:
                game=1
                isboss=1
                pg.mixer_music.load("song-2.mp3")
                pg.mixer_music.play(-1)

        else:
            text_surface = menufont.render('???', False, (0, 0, 0))
            window.blit(text_surface, (690,height/2))

        if (MB4.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_SPACE]:
            game=4
            pg.mixer_music.load("song-2.mp3")
            pg.mixer_music.play(-1)
            
            
            

        

        text_surface = menufont.render('MULTIPLAYER ', False, (0, 0, 0))
        window.blit(text_surface, (690,height/2-200))

        text_surface = menufont.render('Exit game', False, (0, 0, 0))
        window.blit(text_surface, (690,height/2+200))

        if MB6.collidepoint(mousex,mousey) and leftclick:
            break

        if (MB1.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_SPACE]:
            game=1
            isboss=0
            pg.mixer_music.load("song-2.mp3")
            pg.mixer_music.play(-1)
            

        if (MB2.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_c]:
            pg.draw.rect(window,"white",BB)
            text_surface = valuefont.render('Input in', False, (0, 0, 0))
            window.blit(text_surface, (BB.x,BB.y))
            text_surface = valuefont.render('console', False, (0, 0, 0))
            window.blit(text_surface, (BB.x,BB.y+35))
            pg.display.update()   
            cheat=input("Insert cheat:")
            if cheat=="time":
                time=1
                print("time goes brr")
            if cheat=="fund":
                eff=100
                print("where did money that come from")
            if cheat=="easy":
                aieff==0.5
                print("this will be easy,right?")
            if cheat=="medium" or cheat=="normal":
                aieff=1
                print("all right,not sweaty,but not trivial, i like it")
            if cheat=="hard":
                aieff=1.5
                print("lets see how you handle this")
            if cheat=="brutal":
                temp=float(input("Choose brutal modifier strenght:"))

                aieff=1+temp*1
                print("no shot you are beating this")
            if  cheat=="impossible":
                aieff=100
                print("ha ha ha")
            if cheat=="noai":
                aieff=0
                print("if you lose this,i swear")
            if cheat=="fortress":
                hp22=999999999
                print("lets see how they break trough this")
            if cheat=="evil fortress" or cheat=="efortress":
                hp11=999999999
                print("oh shi-")
            if cheat=="quit" or cheat=="exit" or cheat=="bye":
                print("bye")
                break
            if cheat=="seed" or cheat=="random" or cheat=="ran" or cheat=="randomize":
                print("randomizing")
                seed()
            if cheat=="income":
                temp=float(input("koliki velik income:"))
                eff=temp
                print("income je:",eff)
            if cheat=="hp":
                showhp=1
                print("showing hp")
            if cheat=="vol" or cheat=="volume":
                temp=float(input("volume:"))
                pg.mixer.music.set_volume(temp)
                print("*set volume")
            if cheat=="mute":
                pg.mixer.music.set_volume(0)
                print("muted")
            if cheat=="unmute":
                pg.mixer.music.set_volume(100)
                print("unmuted")
            if cheat=="trophy":
                easy=1
                medium=1
                hard=1
                brutal=1
                print("all badges collected")



            if cheat=="reset" or cheat=="r":
                print("reseting all cheats")
                time=0
                eff=1
                aieff=1
                hp11=100
                hp22=100
                showhp=0

        if (MB3.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_s]:
                game=-3

        


    if game==-3:
        window.fill((0,100,150))
        pg.draw.rect(window,"white",SB)

        text_surface = valuefont.render('Menu', False, (0, 0, 0))
        window.blit(text_surface, (0,0))

        if (SB.collidepoint(mousex,mousey) and leftclick):
                game=0

        text_surface = menufont.render('Settings', False, (0, 0, 0))
        window.blit(text_surface, (width/2-200,height/2-400))

        pg.draw.rect(window,"white",LLB1)
        text_surface = upgradefont.render('Easy', False, (0, 0, 0))
        window.blit(text_surface, (LLB1.x,LLB1.y))
        pg.draw.rect(window,"white",LLB2)
        text_surface = upgradefont.render('Medium', False, (0, 0, 0))
        window.blit(text_surface, (LLB2.x,LLB2.y))
        pg.draw.rect(window,"white",LLB3)
        text_surface = upgradefont.render('Hard', False, (0, 0, 0))
        window.blit(text_surface, (LLB3.x,LLB3.y))
        pg.draw.rect(window,"white",LLB4)
        text_surface = upgradefont.render('Brutal', False, (0, 0, 0))
        window.blit(text_surface, (LLB4.x,LLB4.y))
        pg.draw.rect(window,"white",LLB5)
        text_surface = upgradefont.render('Custom', False, (0, 0, 0))
        window.blit(text_surface, (LLB5.x,LLB5.y))

        dif(LLB1,0.5)
        dif(LLB2,1)
        dif(LLB3,1.5)
        dif(LLB4,2.5)

        if LLB5.collidepoint(mousex,mousey) and leftclick:
            pg.draw.rect(window,"white",BB)
            text_surface = valuefont.render('Input in', False, (0, 0, 0))
            window.blit(text_surface, (BB.x,BB.y))
            text_surface = valuefont.render('console', False, (0, 0, 0))
            window.blit(text_surface, (BB.x,BB.y+35))
            pg.display.update()
            temp=float(input("Insert difficulty level:"))
            aieff=temp
            print("difficulty is:",aieff)

        pg.draw.rect(window,"white",LB1)
        text_surface = valuefont.render('Mute', False, (0, 0, 0))
        window.blit(text_surface, (LB1.x,LB1.y))
        text_surface = valuefont.render('/', False, (0, 0, 0))
        window.blit(text_surface, (LB1.x+30,LB1.y+30))
        text_surface = valuefont.render('Unmute', False, (0, 0, 0))
        window.blit(text_surface, (LB1.x,LB1.y+60))
        if volcd==20:
            if LB1.collidepoint(mousex,mousey) and leftclick:
                vol=pg.mixer_music.get_volume()
            
                volcd=0
                if vol==0:
                    pg.mixer_music.set_volume(prevvol)
                else:
                    prevvol=vol
                    pg.mixer_music.set_volume(0)
        else:
            volcd+=1
               

    if game==1:
        window.fill("tan")
        pg.draw.rect(window,"white",LB1,)
        pg.draw.rect(window,"white",LB2,)
        pg.draw.rect(window,"white",LB3,)
        pg.draw.rect(window,"white",LB4,)
        pg.draw.rect(window,"white",LB5,)
        pg.draw.rect(window,"white",LB6,)
        pg.draw.rect(window,"white",LB7,)
        pg.draw.rect(window,"white",LB8,)
        pg.draw.rect(window,"white",LB9,)
        pg.draw.rect(window,"white",LB10,)

        #text_surface = menufont.render('1', False, (0, 0, 0))
        window.blit(frame1[1], LB1)

        #text_surface = menufont.render('2', False, (0, 0, 0))
        window.blit(frame2[1], LB2)

        #text_surface = menufont.render('3', False, (0, 0, 0))
        window.blit(frame3[1], LB3)

        #text_surface = menufont.render('4', False, (0, 0, 0))
        window.blit(frame4[1], LB4)

        #text_surface = menufont.render('5', False, (0, 0, 0))
        window.blit(frame5[1], LB5)

        #text_surface = menufont.render('6', False, (0, 0, 0))
        window.blit(frame6[1], LB6)

        #text_surface = menufont.render('7', False, (0, 0, 0))
        window.blit(frame7[1], LB7)

        #text_surface = menufont.render('8', False, (0, 0, 0))
        window.blit(frame8[1], LB8)

        #text_surface = menufont.render('9', False, (0, 0, 0))
        window.blit(frame9[1], LB9)

        #text_surface = menufont.render('10', False, (0, 0, 0))
        window.blit(frame10[1], LB10)

        pg.draw.rect(window,"white",LLB1)
        pg.draw.rect(window,"white",LLB2)
        pg.draw.rect(window,"white",LLB3)
        pg.draw.rect(window,"white",LLB4)
        pg.draw.rect(window,"white",LLB5)

        disport(cc1,LLB1,2)
        disport(cc2,LLB2,2)
        disport(cc3,LLB3,2)
        disport(cc4,LLB4,2)
        disport(cc5,LLB5,2)
        #text_surface = menufont.render(str(cc1), False, (0, 0, 0))
        #window.blit(text_surface, LLB1)

        #text_surface = menufont.render(str(cc2), False, (0, 0, 0))
        #window.blit(text_surface, LLB2)

        #text_surface = menufont.render(str(cc3), False, (0, 0, 0))
        #window.blit(text_surface, LLB3)

        #text_surface = menufont.render(str(cc4), False, (0, 0, 0))
        #window.blit(text_surface, LLB4)

        #text_surface = menufont.render(str(cc5), False, (0, 0, 0))
        #window.blit(text_surface, LLB5)

        pg.draw.rect(window,"white",BB)

        text_surface = valuefont.render("Reset", False, (0, 0, 0))
        window.blit(text_surface, BB)

        pg.draw.rect(window,"white",SB)

        text_surface = valuefont.render("START", False, (0, 0, 0))
        window.blit(text_surface, SB)

        if (leftclick and BB.collidepoint(mousex,mousey)) or keys[pg.K_BACKSPACE] or keys[pg.K_r]:

            cc1=0
            cc2=0
            cc3=0
            cc4=0
            cc5=0


            

        selchar(LB1,pg.K_1,1)
        selchar(LB2,pg.K_2,2)
        selchar(LB3,pg.K_3,3)
        selchar(LB4,pg.K_4,4)
        selchar(LB4,pg.K_4,4)
        selchar(LB5,pg.K_5,5)
        selchar(LB6,pg.K_6,6)
        selchar(LB7,pg.K_7,7)       
        selchar(LB8,pg.K_8,8)
        selchar(LB9,pg.K_9,9)
        selchar(LB10,pg.K_0,10)

        unselect(LLB1,cc1)
        unselect(LLB2,cc2)
        unselect(LLB3,cc3)
        unselect(LLB4,cc4)
        unselect(LLB5,cc5)

        if (leftclick and SB.collidepoint(mousex,mousey)) or keys[pg.K_KP_ENTER]:
            if not isboss:
                game=2
                mon=0
                monbr=0
                hp1=hp11
                hp2=hp22
                summons1.clear()
                summons2.clear()
                summons2rect.clear()
                summons1rect.clear()
                mon=0
                aimon=0
                upcost=250
                if not aieff>=2:
                    pg.mixer_music.load("song-3.mp3")
                    pg.mixer_music.play(-1)
                    diff=0
                else:
                    pg.mixer_music.load("song-5.mp3")
                    pg.mixer_music.play(-1)
                    diff=1
            else:
                game=3
                mon=0
                monbr=0
                hp1=hp11*10
                hp2=hp22
                summons1.clear()
                summons2.clear()
                summons2rect.clear()
                summons1rect.clear()
                mon=0
                aimon=0
                upcost=250
                aieff=0.3
                pg.mixer_music.load("song-4.mp3")
                pg.mixer_music.play(-1)
                bossbr=0
                timer=0

    if game==4:

        if (leftclick and SB.collidepoint(mousex,mousey)) or keys[pg.K_KP_ENTER]:
            game=6
            eff=1
            aieff=1
            mon=0
            monbr=0
            hp1=hp11
            hp2=hp22
            summons1.clear()
            summons2.clear()
            summons2rect.clear()
            summons1rect.clear()
            mon=0
            aimon=0
            pg.mixer_music.load("song-6.mp3")
            pg.mixer_music.play(-1)
            
        
        window.fill("tan")
        text_surface = menufont.render('Player 1', False, (0, 0, 0))
        window.blit(text_surface, (width/2-200,height/2-400))
        pg.draw.rect(window,"white",LB1,)
        pg.draw.rect(window,"white",LB2,)
        pg.draw.rect(window,"white",LB3,)
        pg.draw.rect(window,"white",LB4,)
        pg.draw.rect(window,"white",LB5,)
        pg.draw.rect(window,"white",LB6,)
        pg.draw.rect(window,"white",LB7,)
        pg.draw.rect(window,"white",LB8,)
        pg.draw.rect(window,"white",LB9,)
        pg.draw.rect(window,"white",LB10,)

        pg.draw.rect(window,"white",BB)

        text_surface = valuefont.render("Reset", False, (0, 0, 0))
        window.blit(text_surface, BB)

        pg.draw.rect(window,"white",SB)

        text_surface = valuefont.render("START", False, (0, 0, 0))
        window.blit(text_surface, SB)

        #text_surface = menufont.render('1', False, (0, 0, 0))
        window.blit(frame1[1], LB1)

        #text_surface = menufont.render('2', False, (0, 0, 0))
        window.blit(frame2[1], LB2)

        #text_surface = menufont.render('3', False, (0, 0, 0))
        window.blit(frame3[1], LB3)

        #text_surface = menufont.render('4', False, (0, 0, 0))
        window.blit(frame4[1], LB4)

        #text_surface = menufont.render('5', False, (0, 0, 0))
        window.blit(frame5[1], LB5)

        #text_surface = menufont.render('6', False, (0, 0, 0))
        window.blit(frame6[1], LB6)

        #text_surface = menufont.render('7', False, (0, 0, 0))
        window.blit(frame7[1], LB7)

        #text_surface = menufont.render('8', False, (0, 0, 0))
        window.blit(frame8[1], LB8)

        #text_surface = menufont.render('9', False, (0, 0, 0))
        window.blit(frame9[1], LB9)

        #text_surface = menufont.render('10', False, (0, 0, 0))
        window.blit(frame10[1], LB10)

        

        pg.draw.rect(window,"white",LLB1)
        pg.draw.rect(window,"white",LLB2)
        pg.draw.rect(window,"white",LLB3)
        pg.draw.rect(window,"white",LLB4)
        pg.draw.rect(window,"white",LLB5)

        

        disport(cc6,LLB1,2)
        disport(cc7,LLB2,2)
        disport(cc8,LLB3,2)
        disport(cc9,LLB4,2)
        disport(cc10,LLB5,2)

        selchar2(LB1,pg.K_1,1)
        selchar2(LB2,pg.K_2,2)
        selchar2(LB3,pg.K_3,3)
        selchar2(LB4,pg.K_4,4)
        selchar2(LB4,pg.K_4,4)
        selchar2(LB5,pg.K_5,5)
        selchar2(LB6,pg.K_6,6)
        selchar2(LB7,pg.K_7,7)       
        selchar2(LB8,pg.K_8,8)
        selchar2(LB9,pg.K_9,9)
        selchar2(LB10,pg.K_0,10)

        if (leftclick and BB.collidepoint(mousex,mousey)) or keys[pg.K_BACKSPACE] or keys[pg.K_r]:

            cc6=0
            cc7=0
            cc8=0
            cc9=0
            cc10=0

        if keys[pg.K_RIGHT]:
            game=5

    if game==5:

        if (leftclick and SB.collidepoint(mousex,mousey)) or keys[pg.K_KP_ENTER]:
            game=6
            eff=1
            aieff=1
            mon=0
            monbr=0
            hp1=hp11
            hp2=hp22
            summons1.clear()
            summons2.clear()
            summons2rect.clear()
            summons1rect.clear()
            mon=0
            aimon=0
            pg.mixer_music.load("song-6.mp3")
            pg.mixer_music.play(-1)
        
        window.fill("tan")
        text_surface = menufont.render('Player 2', False, (0, 0, 0))
        window.blit(text_surface, (width/2-200,height/2-400))
        pg.draw.rect(window,"white",LB1,)
        pg.draw.rect(window,"white",LB2,)
        pg.draw.rect(window,"white",LB3,)
        pg.draw.rect(window,"white",LB4,)
        pg.draw.rect(window,"white",LB5,)
        pg.draw.rect(window,"white",LB6,)
        pg.draw.rect(window,"white",LB7,)
        pg.draw.rect(window,"white",LB8,)
        pg.draw.rect(window,"white",LB9,)
        pg.draw.rect(window,"white",LB10,)

        pg.draw.rect(window,"white",BB)

        text_surface = valuefont.render("Reset", False, (0, 0, 0))
        window.blit(text_surface, BB)

        pg.draw.rect(window,"white",SB)

        text_surface = valuefont.render("START", False, (0, 0, 0))
        window.blit(text_surface, SB)

        #text_surface = menufont.render('1', False, (0, 0, 0))
        window.blit(frame1[1], LB1)

        #text_surface = menufont.render('2', False, (0, 0, 0))
        window.blit(frame2[1], LB2)

        #text_surface = menufont.render('3', False, (0, 0, 0))
        window.blit(frame3[1], LB3)

        #text_surface = menufont.render('4', False, (0, 0, 0))
        window.blit(frame4[1], LB4)

        #text_surface = menufont.render('5', False, (0, 0, 0))
        window.blit(frame5[1], LB5)

        #text_surface = menufont.render('6', False, (0, 0, 0))
        window.blit(frame6[1], LB6)

        #text_surface = menufont.render('7', False, (0, 0, 0))
        window.blit(frame7[1], LB7)

        #text_surface = menufont.render('8', False, (0, 0, 0))
        window.blit(frame8[1], LB8)

        #text_surface = menufont.render('9', False, (0, 0, 0))
        window.blit(frame9[1], LB9)

        #text_surface = menufont.render('10', False, (0, 0, 0))
        window.blit(frame10[1], LB10)

        



        pg.draw.rect(window,"white",LLB1)
        pg.draw.rect(window,"white",LLB2)
        pg.draw.rect(window,"white",LLB3)
        pg.draw.rect(window,"white",LLB4)
        pg.draw.rect(window,"white",LLB5)
        disport(cc1,LLB1,2)
        disport(cc2,LLB2,2)
        disport(cc3,LLB3,2)
        disport(cc4,LLB4,2)
        disport(cc5,LLB5,2)
        selchar(LB1,pg.K_1,1)
        selchar(LB2,pg.K_2,2)
        selchar(LB3,pg.K_3,3)
        selchar(LB4,pg.K_4,4)
        selchar(LB4,pg.K_4,4)
        selchar(LB5,pg.K_5,5)
        selchar(LB6,pg.K_6,6)
        selchar(LB7,pg.K_7,7)       
        selchar(LB8,pg.K_8,8)
        selchar(LB9,pg.K_9,9)
        selchar(LB10,pg.K_0,10)

        

        if (leftclick and BB.collidepoint(mousex,mousey)) or keys[pg.K_BACKSPACE] or keys[pg.K_r]:

            cc1=0
            cc2=0
            cc3=0
            cc4=0
            cc5=0

        if keys[pg.K_LEFT]:
            game=4

        

        

    if game==2:

        if hp1<1:
            game=-1
        if hp2<1:
            game=-2

        if cd!=10:
            cd+=1
        if monbr!=1:
            mon+=eff
            
            aimon+=aieff
        
        else:
            monbr=0
            mon+=eff
            aimon+=eff*2

        #print(aimon)

        char=randint(1,10)
        if randint(0,20)==20:
            
                if char==1 and aimon>=h1:
                    aimon-=h1
                    summons2.append(summon(1,60,1.5,15,3,1,0,0,1,1))
                    summons2rect.append(pg.Rect(30,500,100,100))
                
                if char==2 and aimon>=h2:
                    aimon-=h2
                    summons2.append(summon(2,100,1,35,1,1,0,1,1,1))     #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.9,99,100.1))
                
                if char==3 and aimon>=h3:
                    aimon-=h3
                    summons2.append(summon(3,30,1.5,5,5,10,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.8,98,101.2))
                
                if char==4 and aimon>=h4:
                    aimon-=h4
                    summons2.append(summon(4,100,1,5,10,150,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.7,97,101.3))
                
                if char==5 and aimon>=h5:
                    aimon-=h5
                    summons2.append(summon(5,7,5,7,1,1,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.6,96,101.4))
                
                if char==6 and aimon>=h6:
                    aimon-=h6
                    summons2.append(summon(6,60,1.5,20,5,10,0,1,1,1)) #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.5,95,101.5))
                
                if char==7 and aimon>=h7:
                    aimon-=h7
                    summons2.append(summon(7,80,1.2,20,30,10,0,0,1,1)) 
                    summons2rect.append(pg.Rect(30,499.4,94,101.6))
                
                if char==8 and aimon>=h8:
                    aimon-=h8
                    summons2.append(summon(8,80,1.1,20,20,200,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.3,93,101.7))
                
                if char==9 and aimon>=h9:
                    aimon-=h9
                    summons2.append(summon(9,100,1.1,75 ,50,1,0,1,1,1)) #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.2,92,101.8))
                
                if char==10 and aimon>=h10:
                    aimon-=h10
                    summons2.append(summon(10,1000,1.1,50,1000,500,0,1,1,1)) #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.1,91,101.9))
                    
        if diff==0:
            window.fill((50,150,200))
            pg.draw.rect(window,"lime",(0,600,1280,200))
        else:
            window.fill((200,0,0))
            pg.draw.rect(window,(50,0,0),(0,600,1280,200))

        pg.draw.rect(window,"white",LB1,)
        pg.draw.rect(window,"white",LB2,)
        pg.draw.rect(window,"white",LB3,)
        pg.draw.rect(window,"white",LB4,)
        pg.draw.rect(window,"white",LB5,)
        pg.draw.rect(window,"white",LB10,)

        text_surface = upgradefont.render(str(upcost), False, (0, 0, 0))
        window.blit(text_surface, LB10)

        if upcd==240:
            if (LB10.collidepoint(mousex,mousey) and leftclick) or keys [pg.K_KP_ENTER]:
                if mon>=upcost:
                    upcd=0
                    mon-=upcost
                    upcost*=2
                    eff*=1.2
        else:
            upcd+=1
            

        disport(cc1,LB1,1)
        disport(cc2,LB2,1)
        disport(cc3,LB3,1)
        disport(cc4,LB4,1)
        disport(cc5,LB5,1)
        #text_surface = menufont.render(str(cc1), False, (0, 0, 0))
        #window.blit(text_surface, LB1)
        #text_surface = menufont.render(str(cc2), False, (0, 0, 0))
        #window.blit(text_surface, LB2)
        #text_surface = menufont.render(str(cc3), False, (0, 0, 0))
        #window.blit(text_surface, LB3)
        #text_surface = menufont.render(str(cc4), False, (0, 0, 0))
        #window.blit(text_surface, LB4)
        #text_surface = menufont.render(str(cc5), False, (0, 0, 0))
        #window.blit(text_surface, LB5)

        text_surface = valuefont.render(str(ccp1), False, (0, 0, 0))
        window.blit(text_surface, LB1)
        text_surface = valuefont.render(str(ccp2), False, (0, 0, 0))
        window.blit(text_surface, LB2)
        text_surface = valuefont.render(str(ccp3), False, (0, 0, 0))
        window.blit(text_surface, LB3)
        text_surface = valuefont.render(str(ccp4), False, (0, 0, 0))
        window.blit(text_surface, LB4)
        text_surface = valuefont.render(str(ccp5), False, (0, 0, 0))
        window.blit(text_surface, LB5)

        text_surface = valuefont.render(str(int(mon)), False, (0, 0, 0))
        window.blit(text_surface, BB)
        text_surface = valuefont.render("$", False, (0, 0, 0))
        window.blit(text_surface, (1250,0,100,100))

        pg.draw.rect(window,"gray",t1)
        pg.draw.rect(window,"gray",t2)

        pg.draw.rect(window,"red",(30,200,100,30))
        pg.draw.rect(window,"red",(1030,200,100,30))

        pg.draw.rect(window,"green",(30,200,hp1,30))
        pg.draw.rect(window,"green",(1030,200,hp2,30))

        text_surface = valuefont.render(str(hp1), False, (0, 0, 0))
        window.blit(text_surface, (30,200,100,100))
        text_surface = valuefont.render(str(hp2), False, (0, 0, 0))
        window.blit(text_surface, (1030,200,100,100))

        create(LB1,pg.K_1,cc1)
        create(LB2,pg.K_2,cc2)
        create(LB3,pg.K_3,cc3)
        create(LB4,pg.K_4,cc4)
        create(LB5,pg.K_5,cc5)

        for i in summons1rect:
            n=0

            
                    

            if summons1[summons1rect.index(i)].hp<1:
                summons1.pop(summons1rect.index(i))
                summons1rect.remove(i)
                continue

            

            temprect=pg.Rect(i.x,500,i.x-i.x-summons1[summons1rect.index(i)].range,1)
            if summons1[summons1rect.index(i)].atype==0:

                    tempcollide= temprect.collidelist(summons2rect)
                    if tempcollide!=-1:
                        n=1

                        if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                            summons1[summons1rect.index(i)].atick+=1
                            summons1[summons1rect.index(i)].frametick=1
                        else:
                            summons1[summons1rect.index(i)].atick=0
                            summons1[summons1rect.index(i)].frametick=4
                            
                            summons2[tempcollide].hp-=summons1[summons1rect.index(i)].dmg

            else:
                tempcollide=temprect.collidelistall(summons2rect)
                
                for o in tempcollide:
                    if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                            summons1[summons1rect.index(i)].atick+=1
                            summons1[summons1rect.index(i)].frametick=1
                    else:
                            summons1[summons1rect.index(i)].atick=0
                            summons1[summons1rect.index(i)].frametick=4
                            summons2[o].hp-=summons1[summons1rect.index(i)].dmg
                    n=1

            
            if n==0 and t2.collidepoint(i.x-summons1[summons1rect.index(i)].range,500):
                if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                    summons1[summons1rect.index(i)].atick+=1
                    summons1[summons1rect.index(i)].frametick=1
                    n=1
                else:
                    summons1[summons1rect.index(i)].atick=0
                    summons1[summons1rect.index(i)].frametick=4
                    
                    hp1-=summons1[summons1rect.index(i)].dmg
                    n=1
            

            if n==0:
                if summons1[summons1rect.index(i)].frametick!=3:
                    if summons1[summons1rect.index(i)].frametick2!=10:
                        summons1[summons1rect.index(i)].frametick2+=1
                    else:
                        summons1[summons1rect.index(i)].frametick+=1
                        summons1[summons1rect.index(i)].frametick2=1
                elif summons1[summons1rect.index(i)].frametick==4:
                    summons1[summons1rect.index(i)].frametick=1
                else:
                    if summons1[summons1rect.index(i)].frametick2!=10:
                        summons1[summons1rect.index(i)].frametick2+=1
                    else:
                        summons1[summons1rect.index(i)].frametick=1
                        summons1[summons1rect.index(i)].frametick2=1
                i.x-=summons1[summons1rect.index(i)].mspeed
            if not 0<summons1[summons1rect.index(i)].frametick<5:
                summons1[summons1rect.index(i)].frametick=1

            if summons1[summons1rect.index(i)].sprite==1:
                #pg.draw.rect(window,"white",i)
                
                window.blit(frame1[summons1[summons1rect.index(i)].frametick],i)

                
            elif summons1[summons1rect.index(i)].sprite==2:
                window.blit(frame2[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"red",i)
            elif summons1[summons1rect.index(i)].sprite==3:
                #pg.draw.rect(window,"blue",i)
                window.blit(frame3[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==4:
                #pg.draw.rect(window,"yellow",i)
                window.blit(frame4[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==5:
                window.blit(frame5[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"green",i)
            elif summons1[summons1rect.index(i)].sprite==6:
                window.blit(frame6[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"purple",i)
            elif summons1[summons1rect.index(i)].sprite==7:
                #pg.draw.rect(window,"orange",i)
                window.blit(frame7[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==8:
                #pg.draw.rect(window,"black",i)
                window.blit(frame8[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==9:
                #pg.draw.rect(window,"tan",i)
                window.blit(frame9[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==10:
                #pg.draw.rect(window,"lime",i)
                window.blit(frame10[summons1[summons1rect.index(i)].frametick],i)
                    
            
            if showhp:
                text_surface = valuefont.render(str(summons1[summons1rect.index(i)].hp), False, (0, 0, 0))
                window.blit(text_surface,i)

        for i in summons2rect:
            n=0
            

            if summons2[summons2rect.index(i)].hp<1:
                summons2.pop(summons2rect.index(i))
                summons2rect.remove(i)
                mon+=30
                continue

            


            temprect=pg.Rect(i.x+100,500,summons2[summons2rect.index(i)].range,1)
            if summons2[summons2rect.index(i)].atype==0:

                tempcollide= temprect.collidelist(summons1rect)
                if tempcollide!=-1:
                        n=1
                    #print(tempcollide)
                    
                        if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                            summons2[summons2rect.index(i)].atick+=1
                            summons2[summons2rect.index(i)].frametick=1
                        else:
                            summons2[summons2rect.index(i)].atick=0
                            summons1[tempcollide].hp-=summons2[summons2rect.index(i)].dmg
                            summons2[summons2rect.index(i)].frametick=4

            else:
                tempcollide=temprect.collidelistall(summons1rect)
                for o in tempcollide:
                    if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                            summons2[summons2rect.index(i)].atick+=1
                            summons2[summons2rect.index(i)].frametick=1
                    else:
                            summons2[summons2rect.index(i)].atick=0
                            summons1[o].hp-=summons2[summons2rect.index(i)].dmg
                            summons2[summons2rect.index(i)].frametick=4
                    n=1


            #RADIM NA SPLASH DAMAGE I n stvar
                

            if t1.collidepoint(i.x+summons2[summons2rect.index(i)].range+100,500):
                n=1
                if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                    summons2[summons2rect.index(i)].atick+=1
                    summons2[summons2rect.index(i)].frametick=1
                    n=1
                else:
                    summons2[summons2rect.index(i)].atick=0
                    summons2[summons2rect.index(i)].frametick=4
                    
                    hp2-=summons2[summons2rect.index(i)].dmg
                    n=1

            if n==0:
                if summons2[summons2rect.index(i)].frametick!=3:
                    if summons2[summons2rect.index(i)].frametick2!=10:
                        summons2[summons2rect.index(i)].frametick2+=1
                    else:
                
                        summons2[summons2rect.index(i)].frametick+=1
                        
                        summons2[summons2rect.index(i)].frametick2=1
                elif summons2[summons2rect.index(i)].frametick==4:
                    summons2[summons2rect.index(i)].frametick=4              
                else:
                    if summons2[summons2rect.index(i)].frametick2!=10:
                        summons2[summons2rect.index(i)].frametick2+=1
                    else:
                        summons2[summons2rect.index(i)].frametick=1
                        summons2[summons2rect.index(i)].frametick2=1
                i.x+=summons2[summons2rect.index(i)].mspeed/2
            if summons2[summons2rect.index(i)].frametick==5:
                summons2[summons2rect.index(i)].frametick=1

            if summons2[summons2rect.index(i)].sprite==1:
                
                frame=pg.transform.flip(frame1[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==2:
                frame=pg.transform.flip(frame2[summons2[summons2rect.index(i)].frametick],True,False)
                
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==3:
                frame=pg.transform.flip(frame3[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
                
                
            elif summons2[summons2rect.index(i)].sprite==4:
                frame=pg.transform.flip(frame4[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==5:

                frame=pg.transform.flip(frame5[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==6:
                
                frame=pg.transform.flip(frame6[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==7:
                
                frame=pg.transform.flip(frame7[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==8:
                
                frame=pg.transform.flip(frame8[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==9:
                
                frame=pg.transform.flip(frame9[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==10:
                
                frame=pg.transform.flip(frame10[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
            
            if showhp:
                text_surface = valuefont.render(str(summons2[summons2rect.index(i)].hp), False, (0, 0, 0))
                window.blit(text_surface,i)

    if game==-1:
        eff=1
        trophy()
        window.fill("white")
        text_surface = menufont.render("YOU WIN!", False, (0, 0, 0))
        window.blit(text_surface,(500,300))
        pg.draw.rect(window,"gray",btmb)
        if (btmb.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_KP_ENTER]:
            game=0
            pg.mixer_music.load("song-1.mp3")
            pg.mixer_music.play(-1)
        text_surface = menufont.render("Back to menu", False, (0, 0, 0))
        window.blit(text_surface,(500,500))
    if game==-2:
        eff=1
        window.fill("white")
        text_surface = menufont.render("YOU LOSE!", False, (0, 0, 0))
        window.blit(text_surface,(500,300))
        pg.draw.rect(window,"gray",btmb)
        text_surface = menufont.render("Back to menu", False, (0, 0, 0))
        window.blit(text_surface,(500,500))
        if (btmb.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_KP_ENTER]:
            game=0
            pg.mixer_music.load("song-1.mp3")
            pg.mixer_music.play(-1)

    if game==3:####################################################################################################################################################################################################################
        timer+=1

        if timer%2000==0:
            summons2.append(summon(8,80,1.1,20,20,200,0,0,1,1))
            summons2rect.append(pg.Rect(30,499.3,93,101.7))

        if timer==400:
            summons2.append(summon(10,1000,1.1,50,50,500,0,1,1,1))
            summons2rect.append(pg.Rect(30,499.1,91,101.9))
            
            

        if timer==1200:
            summons2.append(summon(11,1000,1.1,3000,1000,300,0,1,1,1))
            summons2rect.append(pg.Rect(-200,100,200,800))

        if timer%400==0:
            summons2.append(summon(2,100,1,35,1,1,0,1,1,1))     #treba da splashuje
            summons2rect.append(pg.Rect(30,499.9,99,100.1))


        
        window.fill((30,30,30))
        pg.draw.rect(window,"white",(0,600,1280,200),5)
        pg.draw.rect(window,"white",t1,5)
        pg.draw.rect(window,"white",t2,5)
        if hp1<1:
            game=-1
            boss=1
        if hp2<1:
            game=-2

        if cd!=10:
            cd+=1
        if monbr!=1:
            mon+=eff
            #print(eff)
            aimon+=aieff
        
        else:
            monbr=0
            mon+=eff
            aimon+=eff*2

        #print(aimon)

        char=randint(1,10)
        if randint(0,20)==20:
            
                if char==1 and aimon>=h1:
                    aimon-=h1
                    summons2.append(summon(1,60,1.5,15,3,1,0,0,1,1))
                    summons2rect.append(pg.Rect(30,500,100,100))
                
                if char==2 and aimon>=h2:
                    aimon-=h2
                    summons2.append(summon(2,100,1,35,1,1,0,1,1,1))     #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.9,99,100.1))
                
                if char==3 and aimon>=h3:
                    aimon-=h3
                    summons2.append(summon(3,30,1.5,5,5,10,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.8,98,101.2))
                
                if char==4 and aimon>=h4:
                    aimon-=h4
                    summons2.append(summon(4,100,1,5,10,150,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.7,97,101.3))
                
                if char==5 and aimon>=h5:
                    aimon-=h5
                    summons2.append(summon(5,7,5,7,1,1,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.6,96,101.4))
                
                if char==6 and aimon>=h6:
                    aimon-=h6
                    summons2.append(summon(6,60,1.5,20,5,10,0,1,1,1)) #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.5,95,101.5))
                
                if char==7 and aimon>=h7:
                    aimon-=h7
                    summons2.append(summon(7,80,1.2,20,30,10,0,0,1,1)) 
                    summons2rect.append(pg.Rect(30,499.4,94,101.6))
                
                if char==8 and aimon>=h8:
                    aimon-=h8
                    summons2.append(summon(8,80,1.1,20,20,200,0,0,1,1))
                    summons2rect.append(pg.Rect(30,499.3,93,101.7))
                
                if char==9 and aimon>=h9:
                    aimon-=h9
                    summons2.append(summon(9,100,1.1,75 ,50,1,0,1,1,1)) #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.2,92,101.8))
                
                if char==10 and aimon>=h10:
                    aimon-=h10
                    summons2.append(summon(10,1000,1.1,50,1000,500,0,1,1,1)) #treba da splashuje
                    summons2rect.append(pg.Rect(30,499.1,91,101.9))

        pg.draw.rect(window,"white",LB1,)
        pg.draw.rect(window,"white",LB2,)
        pg.draw.rect(window,"white",LB3,)
        pg.draw.rect(window,"white",LB4,)
        pg.draw.rect(window,"white",LB5,)
        pg.draw.rect(window,"white",LB10,)

        text_surface = upgradefont.render(str(upcost), False, (0, 0, 0))
        window.blit(text_surface, LB10)

        if upcd==240:
            if (LB10.collidepoint(mousex,mousey) and leftclick) or keys [pg.K_KP_ENTER]:
                if mon>=upcost:
                    upcd=0
                    mon-=upcost
                    upcost*=2
                    eff*=1.2
        else:
            upcd+=1
            

        disport(cc1,LB1,1)
        disport(cc2,LB2,1)
        disport(cc3,LB3,1)
        disport(cc4,LB4,1)
        disport(cc5,LB5,1)
        #text_surface = menufont.render(str(cc1), False, (0, 0, 0))
        #window.blit(text_surface, LB1)
        #text_surface = menufont.render(str(cc2), False, (0, 0, 0))
        #window.blit(text_surface, LB2)
        #text_surface = menufont.render(str(cc3), False, (0, 0, 0))
        #window.blit(text_surface, LB3)
        #text_surface = menufont.render(str(cc4), False, (0, 0, 0))
        #window.blit(text_surface, LB4)
        #text_surface = menufont.render(str(cc5), False, (0, 0, 0))
        #window.blit(text_surface, LB5)

        text_surface = valuefont.render(str(ccp1), False, (0, 0, 0))
        window.blit(text_surface, LB1)
        text_surface = valuefont.render(str(ccp2), False, (0, 0, 0))
        window.blit(text_surface, LB2)
        text_surface = valuefont.render(str(ccp3), False, (0, 0, 0))
        window.blit(text_surface, LB3)
        text_surface = valuefont.render(str(ccp4), False, (0, 0, 0))
        window.blit(text_surface, LB4)
        text_surface = valuefont.render(str(ccp5), False, (0, 0, 0))
        window.blit(text_surface, LB5)

        text_surface = valuefont.render(str(int(mon)), False, (255, 255, 255))
        window.blit(text_surface, BB)
        text_surface = valuefont.render("$", False, (255, 255, 255))
        window.blit(text_surface, (1250,0,100,100))

        pg.draw.rect(window,"gray",t1)
        pg.draw.rect(window,"gray",t2)

        

        text_surface = valuefont.render(str(hp1), False, (0, 0, 0))
        window.blit(text_surface, (30,200,100,100))
        text_surface = valuefont.render(str(hp2), False, (0, 0, 0))
        window.blit(text_surface, (1030,200,100,100))

        create(LB1,pg.K_1,cc1)
        create(LB2,pg.K_2,cc2)
        create(LB3,pg.K_3,cc3)
        create(LB4,pg.K_4,cc4)
        create(LB5,pg.K_5,cc5)

        for i in summons1rect:
            n=0

            
                    

            if summons1[summons1rect.index(i)].hp<1:
                summons1.pop(summons1rect.index(i))
                summons1rect.remove(i)
                continue

            

            temprect=pg.Rect(i.x,500,i.x-i.x-summons1[summons1rect.index(i)].range,1)
            if summons1[summons1rect.index(i)].atype==0:

                    tempcollide= temprect.collidelist(summons2rect)
                    if tempcollide!=-1:
                        n=1

                        if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                            summons1[summons1rect.index(i)].atick+=1
                            summons1[summons1rect.index(i)].frametick=1
                        else:
                            summons1[summons1rect.index(i)].atick=0
                            summons1[summons1rect.index(i)].frametick=4
                            
                            summons2[tempcollide].hp-=summons1[summons1rect.index(i)].dmg

            else:
                tempcollide=temprect.collidelistall(summons2rect)
                
                for o in tempcollide:
                    if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                            summons1[summons1rect.index(i)].atick+=1
                            summons1[summons1rect.index(i)].frametick=1
                    else:
                            summons1[summons1rect.index(i)].atick=0
                            summons1[summons1rect.index(i)].frametick=4
                            summons2[o].hp-=summons1[summons1rect.index(i)].dmg
                    n=1

            
            if n==0 and t2.collidepoint(i.x-summons1[summons1rect.index(i)].range,500):
                if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                    summons1[summons1rect.index(i)].atick+=1
                    summons1[summons1rect.index(i)].frametick=1
                    n=1
                else:
                    summons1[summons1rect.index(i)].atick=0
                    summons1[summons1rect.index(i)].frametick=4
                    
                    hp1-=summons1[summons1rect.index(i)].dmg
                    n=1
            

            if n==0:
                if summons1[summons1rect.index(i)].frametick!=3:
                    if summons1[summons1rect.index(i)].frametick2!=10:
                        summons1[summons1rect.index(i)].frametick2+=1
                    else:
                        summons1[summons1rect.index(i)].frametick+=1
                        summons1[summons1rect.index(i)].frametick2=1
                elif summons1[summons1rect.index(i)].frametick==4:
                    summons1[summons1rect.index(i)].frametick=1
                else:
                    if summons1[summons1rect.index(i)].frametick2!=10:
                        summons1[summons1rect.index(i)].frametick2+=1
                    else:
                        summons1[summons1rect.index(i)].frametick=1
                        summons1[summons1rect.index(i)].frametick2=1
                i.x-=summons1[summons1rect.index(i)].mspeed
            if not 0<summons1[summons1rect.index(i)].frametick<5:
                summons1[summons1rect.index(i)].frametick=1

            if summons1[summons1rect.index(i)].sprite==1:
                #pg.draw.rect(window,"white",i)
                
                window.blit(frame1[summons1[summons1rect.index(i)].frametick],i)

                
            elif summons1[summons1rect.index(i)].sprite==2:
                window.blit(frame2[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"red",i)
            elif summons1[summons1rect.index(i)].sprite==3:
                #pg.draw.rect(window,"blue",i)
                window.blit(frame3[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==4:
                #pg.draw.rect(window,"yellow",i)
                window.blit(frame4[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==5:
                window.blit(frame5[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"green",i)
            elif summons1[summons1rect.index(i)].sprite==6:
                window.blit(frame6[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"purple",i)
            elif summons1[summons1rect.index(i)].sprite==7:
                #pg.draw.rect(window,"orange",i)
                window.blit(frame7[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==8:
                #pg.draw.rect(window,"black",i)
                window.blit(frame8[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==9:
                #pg.draw.rect(window,"tan",i)
                window.blit(frame9[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==10:
                #pg.draw.rect(window,"lime",i)
                window.blit(frame10[summons1[summons1rect.index(i)].frametick],i)
                    
            
            if showhp:
                text_surface = valuefont.render(str(summons1[summons1rect.index(i)].hp), False, (0, 0, 0))
                window.blit(text_surface,i)

        for i in summons2rect:
            n=0
            
            if summons2[summons2rect.index(i)].sprite==11:
                temprect=pg.Rect(i.x+100,500,summons2[summons2rect.index(i)].range,1)
                if summons2[summons2rect.index(i)].hp<1:
                    summons2.pop(summons2rect.index(i))
                    summons2rect.remove(i)

                tempcollide=temprect.collidelistall(summons1rect)
                    
                for u in tempcollide:
                    n=1
                    if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                            summons2[summons2rect.index(i)].atick+=1
                            summons2[summons2rect.index(i)].frametick=4
                    else:
                            summons2[summons2rect.index(i)].atick=0
                            summons1[u].hp-=summons2[summons2rect.index(i)].dmg
                            bossbr=120
                    
                if t1.collidepoint(i.x+summons2[summons2rect.index(i)].range+100,500):
                    n=1
                    if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                        summons2[summons2rect.index(i)].atick+=1
                        summons2[summons2rect.index(i)].frametick=4
                        n=1
                    else:
                        summons2[summons2rect.index(i)].atick=0
                        bossbr=120
                        
                        hp2-=summons2[summons2rect.index(i)].dmg
                        n=1

                if n==0:
                    if summons2[summons2rect.index(i)].frametick!=3:
                        if summons2[summons2rect.index(i)].frametick2!=10:
                            summons2[summons2rect.index(i)].frametick2+=1
                        else:
                    
                            summons2[summons2rect.index(i)].frametick+=1
                            
                            summons2[summons2rect.index(i)].frametick2=1
                    elif summons2[summons2rect.index(i)].frametick==4:
                        summons2[summons2rect.index(i)].frametick=4              
                    else:
                        if summons2[summons2rect.index(i)].frametick2!=10:
                            summons2[summons2rect.index(i)].frametick2+=1
                        else:
                            summons2[summons2rect.index(i)].frametick=1
                            summons2[summons2rect.index(i)].frametick2=1
                    i.x+=summons2[summons2rect.index(i)].mspeed/2

                
                if bossbr!=0:
                        summons2[summons2rect.index(i)].frametick=5
                        bossbr-=1

                if summons2[summons2rect.index(i)].frametick>5:
                    summons2[summons2rect.index(i)].frametick=1

                window.blit(frame11[summons2[summons2rect.index(i)].frametick],i)



                continue

            if summons2[summons2rect.index(i)].hp<1:
                summons2.pop(summons2rect.index(i))
                summons2rect.remove(i)
                mon+=30
                continue

            


            temprect=pg.Rect(i.x+100,500,summons2[summons2rect.index(i)].range,1)
            if summons2[summons2rect.index(i)].atype==0:

                tempcollide= temprect.collidelist(summons1rect)
                if tempcollide!=-1:
                        n=1
                    #print(tempcollide)
                    
                        if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                            summons2[summons2rect.index(i)].atick+=1
                            summons2[summons2rect.index(i)].frametick=1
                        else:
                            summons2[summons2rect.index(i)].atick=0
                            summons1[tempcollide].hp-=summons2[summons2rect.index(i)].dmg
                            summons2[summons2rect.index(i)].frametick=4

            else:
                tempcollide=temprect.collidelistall(summons1rect)
                for o in tempcollide:
                    if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                            summons2[summons2rect.index(i)].atick+=1
                            summons2[summons2rect.index(i)].frametick=1
                    else:
                            summons2[summons2rect.index(i)].atick=0
                            summons1[o].hp-=summons2[summons2rect.index(i)].dmg
                            summons2[summons2rect.index(i)].frametick=4
                    n=1


            #RADIM NA SPLASH DAMAGE I n stvar
                

            if t1.collidepoint(i.x+summons2[summons2rect.index(i)].range+100,500):
                n=1
                if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                    summons2[summons2rect.index(i)].atick+=1
                    summons2[summons2rect.index(i)].frametick=1
                    n=1
                else:
                    summons2[summons2rect.index(i)].atick=0
                    summons2[summons2rect.index(i)].frametick=4
                    
                    hp2-=summons2[summons2rect.index(i)].dmg
                    n=1

            if n==0:
                if summons2[summons2rect.index(i)].frametick!=3:
                    if summons2[summons2rect.index(i)].frametick2!=10:
                        summons2[summons2rect.index(i)].frametick2+=1
                    else:
                
                        summons2[summons2rect.index(i)].frametick+=1
                        
                        summons2[summons2rect.index(i)].frametick2=1
                elif summons2[summons2rect.index(i)].frametick==4:
                    summons2[summons2rect.index(i)].frametick=4              
                else:
                    if summons2[summons2rect.index(i)].frametick2!=10:
                        summons2[summons2rect.index(i)].frametick2+=1
                    else:
                        summons2[summons2rect.index(i)].frametick=1
                        summons2[summons2rect.index(i)].frametick2=1
                i.x+=summons2[summons2rect.index(i)].mspeed/2
            if summons2[summons2rect.index(i)].frametick==5:
                summons2[summons2rect.index(i)].frametick=1

            if summons2[summons2rect.index(i)].sprite==1:
                
                frame=pg.transform.flip(frame1[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==2:
                frame=pg.transform.flip(frame2[summons2[summons2rect.index(i)].frametick],True,False)
                
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==3:
                frame=pg.transform.flip(frame3[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
                
                
            elif summons2[summons2rect.index(i)].sprite==4:
                frame=pg.transform.flip(frame4[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==5:

                frame=pg.transform.flip(frame5[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==6:
                
                frame=pg.transform.flip(frame6[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==7:
                
                frame=pg.transform.flip(frame7[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==8:
                
                frame=pg.transform.flip(frame8[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==9:
                
                frame=pg.transform.flip(frame9[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==10:
                
                frame=pg.transform.flip(frame10[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
            
            if showhp:
                text_surface = valuefont.render(str(summons2[summons2rect.index(i)].hp), False, (0, 0, 0))
                window.blit(text_surface,i)
                    
            
    #print(aimon)

    if game==6:

        if hp1<1:
            game=-4
        if hp2<1:
            game=-5

        if cd!=10:
            cd+=1
        if monbr!=1:
            mon+=eff
            
            aimon+=aieff
        
        else:
            monbr=0
            mon+=eff
            aimon+=eff*2
            
        if diff==0:
            window.fill((50,150,200))
            pg.draw.rect(window,"lime",(0,600,1280,200))
        else:
            window.fill((200,0,0))
            pg.draw.rect(window,(50,0,0),(0,600,1280,200))

        pg.draw.line(window,"red",(595,600),(595,850),5)
        pg.draw.rect(window,"white",LB1,)
        pg.draw.rect(window,"white",LB2,)
        pg.draw.rect(window,"white",LB3,)
        pg.draw.rect(window,"white",LB4,)
        pg.draw.rect(window,"white",LB5,)
        pg.draw.rect(window,"white",LB6,)
        pg.draw.rect(window,"white",LB7,)
        pg.draw.rect(window,"white",LB8,)
        pg.draw.rect(window,"white",LB9,)
        pg.draw.rect(window,"white",LB10,)


            

        disport(cc1,LB6,1)
        disport(cc2,LB7,1)
        disport(cc3,LB8,1)
        disport(cc4,LB9,1)
        disport(cc5,LB10,1)

        disport(cc6,LB1,1)
        disport(cc7,LB2,1)
        disport(cc8,LB3,1)
        disport(cc9,LB4,1)
        disport(cc10,LB5,1)
        

        text_surface = valuefont.render(str(ccp6), False, (0, 0, 0))
        window.blit(text_surface, LB1)
        text_surface = valuefont.render(str(ccp7), False, (0, 0, 0))
        window.blit(text_surface, LB2)
        text_surface = valuefont.render(str(ccp8), False, (0, 0, 0))
        window.blit(text_surface, LB3)
        text_surface = valuefont.render(str(ccp9), False, (0, 0, 0))
        window.blit(text_surface, LB4)
        text_surface = valuefont.render(str(ccp10), False, (0, 0, 0))
        window.blit(text_surface, LB5)
        text_surface = valuefont.render(str(ccp1), False, (0, 0, 0))
        window.blit(text_surface, LB6)
        text_surface = valuefont.render(str(ccp2), False, (0, 0, 0))
        window.blit(text_surface, LB7)
        text_surface = valuefont.render(str(ccp3), False, (0, 0, 0))
        window.blit(text_surface, LB8)
        text_surface = valuefont.render(str(ccp4), False, (0, 0, 0))
        window.blit(text_surface, LB9)
        text_surface = valuefont.render(str(ccp5), False, (0, 0, 0))
        window.blit(text_surface, LB10)

        text_surface = valuefont.render(str(int(mon)), False, (0, 0, 0))
        window.blit(text_surface, BB)
        text_surface = valuefont.render("$", False, (0, 0, 0))
        window.blit(text_surface, (1250,0,100,100))

        text_surface = valuefont.render(str(int(aimon)), False, (0, 0, 0))
        window.blit(text_surface, SB)
        text_surface = valuefont.render("$", False, (0, 0, 0))
        window.blit(text_surface, (70,0,100,100))

        pg.draw.rect(window,"gray",t1)
        pg.draw.rect(window,"gray",t2)

        pg.draw.rect(window,"red",(30,200,100,30))
        pg.draw.rect(window,"red",(1030,200,100,30))

        pg.draw.rect(window,"green",(30,200,hp1,30))
        pg.draw.rect(window,"green",(1030,200,hp2,30))

        text_surface = valuefont.render(str(hp1), False, (0, 0, 0))
        window.blit(text_surface, (30,200,100,100))
        text_surface = valuefont.render(str(hp2), False, (0, 0, 0))
        window.blit(text_surface, (1030,200,100,100))

        create(LB6,pg.K_6,cc1)
        create(LB7,pg.K_7,cc2)
        create(LB8,pg.K_8,cc3)
        create(LB9,pg.K_9,cc4)
        create(LB10,pg.K_0,cc5)
        create2(LB1,pg.K_1,cc6)
        create2(LB2,pg.K_2,cc7)
        create2(LB3,pg.K_3,cc8)
        create2(LB4,pg.K_4,cc9)
        create2(LB5,pg.K_5,cc10)

        for i in summons1rect:
            n=0

            
                    

            if summons1[summons1rect.index(i)].hp<1:
                summons1.pop(summons1rect.index(i))
                summons1rect.remove(i)
                aimon+=30
                continue

            

            temprect=pg.Rect(i.x,500,i.x-i.x-summons1[summons1rect.index(i)].range,1)
            if summons1[summons1rect.index(i)].atype==0:

                    tempcollide= temprect.collidelist(summons2rect)
                    if tempcollide!=-1:
                        n=1

                        if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                            summons1[summons1rect.index(i)].atick+=1
                            summons1[summons1rect.index(i)].frametick=1
                        else:
                            summons1[summons1rect.index(i)].atick=0
                            summons1[summons1rect.index(i)].frametick=4
                            
                            summons2[tempcollide].hp-=summons1[summons1rect.index(i)].dmg

            else:
                tempcollide=temprect.collidelistall(summons2rect)
                
                for o in tempcollide:
                    if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                            summons1[summons1rect.index(i)].atick+=1
                            summons1[summons1rect.index(i)].frametick=1
                    else:
                            summons1[summons1rect.index(i)].atick=0
                            summons1[summons1rect.index(i)].frametick=4
                            summons2[o].hp-=summons1[summons1rect.index(i)].dmg
                    n=1

            
            if n==0 and t2.collidepoint(i.x-summons1[summons1rect.index(i)].range,500):
                if summons1[summons1rect.index(i)].atick!=summons1[summons1rect.index(i)].aspeed:
                    summons1[summons1rect.index(i)].atick+=1
                    summons1[summons1rect.index(i)].frametick=1
                    n=1
                else:
                    summons1[summons1rect.index(i)].atick=0
                    summons1[summons1rect.index(i)].frametick=4
                    
                    hp1-=summons1[summons1rect.index(i)].dmg
                    n=1
            

            if n==0:
                if summons1[summons1rect.index(i)].frametick!=3:
                    if summons1[summons1rect.index(i)].frametick2!=10:
                        summons1[summons1rect.index(i)].frametick2+=1
                    else:
                        summons1[summons1rect.index(i)].frametick+=1
                        summons1[summons1rect.index(i)].frametick2=1
                elif summons1[summons1rect.index(i)].frametick==4:
                    summons1[summons1rect.index(i)].frametick=1
                else:
                    if summons1[summons1rect.index(i)].frametick2!=10:
                        summons1[summons1rect.index(i)].frametick2+=1
                    else:
                        summons1[summons1rect.index(i)].frametick=1
                        summons1[summons1rect.index(i)].frametick2=1
                i.x-=summons1[summons1rect.index(i)].mspeed
            if not 0<summons1[summons1rect.index(i)].frametick<5:
                summons1[summons1rect.index(i)].frametick=1

            if summons1[summons1rect.index(i)].sprite==1:
                #pg.draw.rect(window,"white",i)
                
                window.blit(frame1[summons1[summons1rect.index(i)].frametick],i)

                
            elif summons1[summons1rect.index(i)].sprite==2:
                window.blit(frame2[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"red",i)
            elif summons1[summons1rect.index(i)].sprite==3:
                #pg.draw.rect(window,"blue",i)
                window.blit(frame3[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==4:
                #pg.draw.rect(window,"yellow",i)
                window.blit(frame4[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==5:
                window.blit(frame5[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"green",i)
            elif summons1[summons1rect.index(i)].sprite==6:
                window.blit(frame6[summons1[summons1rect.index(i)].frametick],i)
                #pg.draw.rect(window,"purple",i)
            elif summons1[summons1rect.index(i)].sprite==7:
                #pg.draw.rect(window,"orange",i)
                window.blit(frame7[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==8:
                #pg.draw.rect(window,"black",i)
                window.blit(frame8[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==9:
                #pg.draw.rect(window,"tan",i)
                window.blit(frame9[summons1[summons1rect.index(i)].frametick],i)
            elif summons1[summons1rect.index(i)].sprite==10:
                #pg.draw.rect(window,"lime",i)
                window.blit(frame10[summons1[summons1rect.index(i)].frametick],i)
                    
            
            if showhp:
                text_surface = valuefont.render(str(summons1[summons1rect.index(i)].hp), False, (0, 0, 0))
                window.blit(text_surface,i)

        for i in summons2rect:
            n=0
            

            if summons2[summons2rect.index(i)].hp<1:
                summons2.pop(summons2rect.index(i))
                summons2rect.remove(i)
                mon+=30
                continue

            


            temprect=pg.Rect(i.x+100,500,summons2[summons2rect.index(i)].range,1)
            if summons2[summons2rect.index(i)].atype==0:

                tempcollide= temprect.collidelist(summons1rect)
                if tempcollide!=-1:
                        n=1
                    #print(tempcollide)
                    
                        if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                            summons2[summons2rect.index(i)].atick+=1
                            summons2[summons2rect.index(i)].frametick=1
                        else:
                            summons2[summons2rect.index(i)].atick=0
                            summons1[tempcollide].hp-=summons2[summons2rect.index(i)].dmg
                            summons2[summons2rect.index(i)].frametick=4

            else:
                tempcollide=temprect.collidelistall(summons1rect)
                for o in tempcollide:
                    if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                            summons2[summons2rect.index(i)].atick+=1
                            summons2[summons2rect.index(i)].frametick=1
                    else:
                            summons2[summons2rect.index(i)].atick=0
                            summons1[o].hp-=summons2[summons2rect.index(i)].dmg
                            summons2[summons2rect.index(i)].frametick=4
                    n=1


            #RADIM NA SPLASH DAMAGE I n stvar
                

            if t1.collidepoint(i.x+summons2[summons2rect.index(i)].range+100,500):
                n=1
                if summons2[summons2rect.index(i)].atick!=summons2[summons2rect.index(i)].aspeed:
                    summons2[summons2rect.index(i)].atick+=1
                    summons2[summons2rect.index(i)].frametick=1
                    n=1
                else:
                    summons2[summons2rect.index(i)].atick=0
                    summons2[summons2rect.index(i)].frametick=4
                    
                    hp2-=summons2[summons2rect.index(i)].dmg
                    n=1

            if n==0:
                if summons2[summons2rect.index(i)].frametick!=3:
                    if summons2[summons2rect.index(i)].frametick2!=10:
                        summons2[summons2rect.index(i)].frametick2+=1
                    else:
                
                        summons2[summons2rect.index(i)].frametick+=1
                        
                        summons2[summons2rect.index(i)].frametick2=1
                elif summons2[summons2rect.index(i)].frametick==4:
                    summons2[summons2rect.index(i)].frametick=4              
                else:
                    if summons2[summons2rect.index(i)].frametick2!=10:
                        summons2[summons2rect.index(i)].frametick2+=1
                    else:
                        summons2[summons2rect.index(i)].frametick=1
                        summons2[summons2rect.index(i)].frametick2=1
                i.x+=summons2[summons2rect.index(i)].mspeed
            if summons2[summons2rect.index(i)].frametick==5:
                summons2[summons2rect.index(i)].frametick=1

            if summons2[summons2rect.index(i)].sprite==1:
                
                frame=pg.transform.flip(frame1[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==2:
                frame=pg.transform.flip(frame2[summons2[summons2rect.index(i)].frametick],True,False)
                
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==3:
                frame=pg.transform.flip(frame3[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
                
                
            elif summons2[summons2rect.index(i)].sprite==4:
                frame=pg.transform.flip(frame4[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==5:

                frame=pg.transform.flip(frame5[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
                
            elif summons2[summons2rect.index(i)].sprite==6:
                
                frame=pg.transform.flip(frame6[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==7:
                
                frame=pg.transform.flip(frame7[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==8:
                
                frame=pg.transform.flip(frame8[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==9:
                
                frame=pg.transform.flip(frame9[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)

            elif summons2[summons2rect.index(i)].sprite==10:
                
                frame=pg.transform.flip(frame10[summons2[summons2rect.index(i)].frametick],True,False)
                window.blit(frame,i)
            
            if showhp:
                text_surface = valuefont.render(str(summons2[summons2rect.index(i)].hp), False, (0, 0, 0))
                window.blit(text_surface,i)

    if game==-4:
        eff=1
        trophy()
        window.fill("white")
        text_surface = menufont.render("PLAYER 1 WINS", False, (0, 0, 0))
        window.blit(text_surface,(500,300))
        pg.draw.rect(window,"gray",btmb)
        if (btmb.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_KP_ENTER]:
            game=0
            pg.mixer_music.load("song-1.mp3")
            pg.mixer_music.play(-1)
        text_surface = menufont.render("Back to menu", False, (0, 0, 0))
        window.blit(text_surface,(500,500))
    if game==-5:
        eff=1
        window.fill("white")
        text_surface = menufont.render("PLAYER 2 WINS", False, (0, 0, 0))
        window.blit(text_surface,(500,300))
        pg.draw.rect(window,"gray",btmb)
        text_surface = menufont.render("Back to menu", False, (0, 0, 0))
        window.blit(text_surface,(500,500))
        if (btmb.collidepoint(mousex,mousey) and leftclick) or keys[pg.K_KP_ENTER]:
            game=0
            pg.mixer_music.load("song-1.mp3")
            pg.mixer_music.play(-1)


    pg.display.update()
    if time==0:
        pg.time.Clock().tick(60)